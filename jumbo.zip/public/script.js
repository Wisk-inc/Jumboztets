var devFlag = false;
function showConfirm(message, opts = {}) {
  return new Promise(resolve => {
    let old = document.getElementById('customConfirmOverlay');
    if (old) old.remove();
    const overlay = document.createElement('div');
    overlay.id = 'customConfirmOverlay';
    overlay.style = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;';
    const isLight = document.body.classList.contains('light');
    const box = document.createElement('div');
    box.style = `background:${isLight ? '#fff' : '#23272f'};color:${isLight ? '#222' : '#f3f3f3'};padding:2em 1.5em;border-radius:14px;max-width:95vw;width:350px;box-shadow:0 8px 32px #0003;text-align:center;`;
    box.innerHTML = `<div style='font-size:1.2em;margin-bottom:1em;'>${message}</div>`;
    const btns = document.createElement('div');
    btns.style = 'margin-top:1.5em;display:flex;gap:1em;justify-content:center;';
    const yesBtn = document.createElement('button');
    yesBtn.textContent = opts.yesText || 'Yes';
    yesBtn.style = `background:${isLight ? '#10a37f' : '#10a37f'};color:#fff;border:none;padding:7px 18px;border-radius:8px;cursor:pointer;`;
    yesBtn.onclick = () => { overlay.remove(); resolve(true); };
    const noBtn = document.createElement('button');
    noBtn.textContent = opts.noText || 'No';
    noBtn.style = `background:${isLight ? '#888' : '#444'};color:#fff;border:none;padding:7px 18px;border-radius:8px;cursor:pointer;`;
    noBtn.onclick = () => { overlay.remove(); resolve(false); };
    btns.appendChild(yesBtn);
    btns.appendChild(noBtn);
    box.appendChild(btns);
    overlay.appendChild(box);
    document.body.appendChild(overlay);
  });
}
function showPopup(message, opts = {}) {
  let old = document.getElementById('customPopupOverlay');
  if (old) old.remove();
  const overlay = document.createElement('div');
  overlay.id = 'customPopupOverlay';
  overlay.style = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.5);display:flex;align-items:center;justify-content:center;';
  const isLight = document.body.classList.contains('light');
  const box = document.createElement('div');
  box.style = `background:${isLight ? '#fff' : '#23272f'};color:${isLight ? '#222' : '#f3f3f3'};padding:2em 1.5em;border-radius:14px;max-width:95vw;width:350px;box-shadow:0 8px 32px #0003;text-align:center;`;
  box.innerHTML = `<div style='font-size:1.2em;margin-bottom:1em;'>${message}</div>`;
  const closeBtn = document.createElement('button');
  closeBtn.textContent = opts.buttonText || 'OK';
  closeBtn.style = `margin-top:1em;background:${isLight ? '#10a37f' : '#10a37f'};color:#fff;border:none;padding:7px 18px;border-radius:8px;cursor:pointer;`;
  closeBtn.onclick = () => overlay.remove();
  box.appendChild(closeBtn);
  overlay.appendChild(box);
  document.body.appendChild(overlay);
}
function getLocalStorageSizeBytes() {
  let total = 0;
  for (let key in localStorage) {
    if (!localStorage.hasOwnProperty(key)) continue;
    const value = localStorage.getItem(key);
    total += key.length + (value ? value.length : 0);
  }
  return total;
}
function showStorageWarningPopup() {
  let old = document.getElementById('storageWarningPopup');
  if (old) old.remove();
  const overlay = document.createElement('div');
  overlay.id = 'storageWarningPopup';
  overlay.style = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center;';
  const isLight = document.body.classList.contains('light');
  const box = document.createElement('div');
  box.style = `background:${isLight ? '#fff' : '#23272f'};color:${isLight ? '#222' : '#f3f3f3'};padding:2em;border-radius:14px;max-width:95vw;width:400px;box-shadow:0 8px 32px #0003;text-align:center;`;
  box.innerHTML = `<h2>Warning!</h2><p>Your browser will restrict storage at 5 MB.<br>You are currently at 4 MB.<br>Here are some chats taking up storage you can delete:</p>`;
  const chats = JSON.parse(localStorage.getItem('conversations_v1') || '[]');
  const list = document.createElement('ul');
  list.style = 'text-align:left;max-height:200px;overflow:auto;margin:1em 0;padding:0 0 0 1em;';
  chats.forEach(c => {
    const li = document.createElement('li');
    li.style = 'margin-bottom:0.5em;';
    li.textContent = (c.title || 'Untitled') + (c.messages && c.messages.length ? ` (${c.messages.length} msg)` : '');
    const delBtn = document.createElement('button');
    delBtn.textContent = 'Delete';
    delBtn.style = `margin-left:1em;background:#e74c3c;color:#fff;border:none;padding:3px 10px;border-radius:6px;cursor:pointer;`;
    delBtn.onclick = function() {
      const idx = chats.findIndex(x => x.id === c.id);
      if (idx !== -1) {
        chats.splice(idx, 1);
        localStorage.setItem('conversations_v1', JSON.stringify(chats));
        li.remove();
        if (typeof hydrate === 'function') hydrate();
        if (getLocalStorageSizeBytes() < 4 * 1024 * 1024) overlay.remove();
      }
    };
    li.appendChild(delBtn);
    list.appendChild(li);
  });
  box.appendChild(list);
  const closeBtn = document.createElement('button');
  closeBtn.textContent = 'Close';
  closeBtn.style = `margin-top:1em;background:${isLight ? '#888' : '#444'};color:#fff;border:none;padding:7px 18px;border-radius:8px;cursor:pointer;`;
  closeBtn.onclick = () => overlay.remove();
  box.appendChild(closeBtn);
  overlay.appendChild(box);
  document.body.appendChild(overlay);
}
function checkStorageWarning() {
  if (getLocalStorageSizeBytes() >= 4 * 1024 * 1024) {
    showStorageWarningPopup();
  }
}
let imageMode = false;
document.getElementById('imageToggle').addEventListener('click', () => {
  setActiveTool(imageMode ? null : 'image');
});
let jsFixMode = false;
const jsFixToggle = document.getElementById('jsFixToggle');
jsFixToggle.addEventListener('click', () => { setActiveTool(jsFixMode ? null : 'jsfix'); });
let thinkMode = false;
let thinkAbortToken = 0;
const thinkToggle = document.getElementById('thinkToggle');
if (thinkToggle) {
  thinkToggle.addEventListener('click', () => { setActiveTool(thinkMode ? null : 'think'); });
}
let webSearchMode = false;
function setActiveTool(toolName) {
  imageMode = toolName === 'image';
  jsFixMode = toolName === 'jsfix';
  thinkMode = toolName === 'think';
  webSearchMode = toolName === 'web';
  const imgBtn = document.getElementById('imageToggle');
  if (imgBtn) imgBtn.classList.toggle('primary', imageMode);
  if (!imageMode) document.getElementById('imageToggle')?.classList.remove('primary');
  const jsBtn = document.getElementById('jsFixToggle');
  if (jsBtn) jsBtn.classList.toggle('primary', jsFixMode);
  const thinkBtn = document.getElementById('thinkToggle');
  if (thinkBtn) thinkBtn.classList.toggle('primary', thinkMode);
  const webBtnLocal = document.getElementById('webSearch');
  if (webBtnLocal) webBtnLocal.classList.toggle('primary', webSearchMode);
  if (!thinkMode) thinkAbortToken++;
}
const discordRedir = document.getElementById('discordRedir');
discordRedir.addEventListener('click', () => {
window.open("https://dc.gg/jumbo", "_blank");
});
const firebaseConfig = {
  apiKey: "AIzaSyDm1t9E0MWxtvleLnA8iy09CYQJbHpt80s",
  authDomain: "jumbo-v1.firebaseapp.com",
  projectId: "jumbo-v1",
  storageBucket: "jumbo-v1.firebasestorage.app",
  messagingSenderId: "376357438762",
  appId: "1:376357438762:web:02cbb3682c0ee7f5708a53",
  measurementId: "G-7B7CFH346F"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
let currentUser = null;
const loginPopup = document.getElementById('loginPopup');
const googleLoginBtn = document.getElementById('googleLogin');
const guestLoginBtn = document.getElementById('guestLogin');
const accountBtn = document.getElementById("accountBtn");
const accountPopup = document.getElementById("accountPopup");
const accountBody = document.getElementById("accountBody");
const closeAccount = document.getElementById("closeAccount");
const modelSelectBtn = document.getElementById('modelSelectBtn');
const dropdown = modelSelectBtn.closest('.dropdown');
modelSelectBtn.addEventListener('click', () => {
  dropdown.classList.toggle('open');
});
document.addEventListener('click', (e) => {
  if (!dropdown.contains(e.target)) {
    dropdown.classList.remove('open');
  }
});
auth.onAuthStateChanged(user => {
  currentUser = user;
  if (user) {
    localStorage.setItem("authMode", "firebase");
    loginPopup.style.display = 'none';
  } else {
    if (localStorage.getItem("authMode") === "guest") {
      loginPopup.style.display = 'none';
    } else {
      loginPopup.style.display = 'flex';
    }
  }
});
function loginWithGoogle() {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider).catch(err => showPopup("Login failed: " + err.message, {buttonText:'Close'}));
}
function logout() {
  auth.signOut().then(() => {
    localStorage.removeItem("authMode");
    renderAccountPopup();
    accountPopup.style.display = "none";
    loginPopup.style.display = "flex";
  });
}
googleLoginBtn.addEventListener('click', () => {
  localStorage.setItem('authMode', 'firebase');
  loginWithGoogle();
  loginPopup.style.display = 'none';
});
guestLoginBtn.addEventListener('click', () => {
  localStorage.setItem('authMode', 'guest');
  loginPopup.style.display = 'none';
});
function renderAccountPopup() {
  accountBody.innerHTML = "";
  const conv = currentConv();
  const mode = localStorage.getItem("authMode");
  if (currentUser) {
    accountBody.innerHTML = `
      <p><i class="fa-solid fa-user"></i> ${currentUser.displayName || "Google User"}</p>
      <p style="font-size:0.9em; color:gray;">${currentUser.email}</p>
      <img src="${currentUser.photoURL}" alt="avatar" style="width:64px; height:64px; border-radius:50%; margin:10px auto; display:block;">
      <button id="logoutBtn" class="btn">Log out</button>
    `;
    document.getElementById("logoutBtn").onclick = () => { logout(); };
  } else if (mode === "guest") {
    accountBody.innerHTML = `
      <h2>Guest Mode</h2>
      <p>You are browsing as guest.</p>
      <button id="switchBtn" class="btn">Switch to Account</button>
    `;
    document.getElementById("switchBtn").onclick = () => {
      localStorage.removeItem("authMode");
      accountPopup.style.display = "none";
      loginPopup.style.display = "flex";
    };
  } else {
    accountBody.innerHTML = `
      <button id="googleLoginPopup" class="btn"><i class="fa-brands fa-google"></i> Login with Google</button>
      <button id="guestLoginPopup" class="btn"><i class="fa-solid fa-user-secret"></i> Continue as Guest</button>
    `;
    document.getElementById("googleLoginPopup").onclick = () => {
      localStorage.setItem('authMode', 'firebase');
      loginWithGoogle();
      accountPopup.style.display = 'none';
    };
    document.getElementById("guestLoginPopup").onclick = () => {
      localStorage.setItem("authMode", "guest");
      accountPopup.style.display = "none";
    };
  }
}
accountBtn.onclick = () => {
  renderAccountPopup();
  accountPopup.style.display = "flex";
};
closeAccount.onclick = () => {
  accountPopup.style.display = "none";
};
if (localStorage.getItem("authMode") === "guest" || auth.currentUser) {
  loginPopup.style.display = 'none';
  setTimeout(hydrate, 1000);
} else {
  loginPopup.style.display = 'flex';
  setTimeout(hydrate, 1000);
}
function autocorrect(input) {
  const informalToFormal = {
    "\\bnigger\\b": "",
    "\\bnigga\\b": "",
    "\\bu\\b": "you",
    "\\bur\\b": "your",
    "\\br\\b": "are",
    "\\bpls\\b": "please",
    "\\bplz\\b": "please",
    "\\bthx\\b": "thanks",
    "\\bimo\\b": "in my opinion",
    "\\bidk\\b": "i dont know",
    "\\bomg\\b": "oh my god",
    "\\bbrb\\b": "be right back",
    "\\bgtg\\b": "got to go",
    "\\btbh\\b": "to be honest",
    "\\bikr\\b": "i know right",
    "\\blmk\\b": "let me know",
    "\\bsmh\\b": "shaking my head",
    "\\bnp\\b": "no problem",
    "\\bbtw\\b": "by the way",
    "\\bmsg\\b": "message",
    "\\bpic\\b": "picture",
    "\\bvid\\b": "video",
    "\\bwanna\\b": "want to",
    "\\bgonna\\b": "going to",
    "\\bgimme\\b": "give me",
    "\\blemme\\b": "let me",
    "\\bkinda\\b": "kind of",
    "\\bsorta\\b": "sort of",
    "\\bcuz\\b": "because",
    "\\bcause\\b": "because",
    "\\bsup\\b": "whats up",
    "\\byeah\\b": "yes",
    "\\byep\\b": "yes",
    "\\bnope\\b": "no",
    "\\bnah\\b": "no",
    "\\bttyl\\b": "talk to you later",
    "\\bfyi\\b": "for your information",
    "\\bw/e\\b": "whatever",
    "\\bw/o\\b": "without",
    "\\bwth\\b": "what the hell",
    "\\bwtf\\b": "what the fuck",
    "\\bbtw\\b": "by the way",
    "\\bgr8\\b": "great",
    "\\bb4\\b": "before",
    "\\b2day\\b": "today",
    "\\b2moro\\b": "tomorrow",
    "\\btho\\b": "though",
    "\\btmrw\\b": "tomorrow",
    "\\bbc\\b": "because",
    "\\bhbu\\b": "how about you",
    "\\bhmu\\b": "hit me up",
    "\\bicymi\\b": "in case you missed it",
    "\\bnvm\\b": "never mind",
    "\\btxt\\b": "text",
    "\\brn\\b": "right now",
    "\\brly\\b": "really",
    "\\bsry\\b": "sorry",
    "\\baf\\b": "as fuck",
    "\\bdyk\\b": "did you know",
    "\\bily\\b": "I love you",
    "\\bily2\\b": "I love you too",
    "\\bty\\b": "thank you",
    "\\bfam\\b": "family",
    "\\bbae\\b": "before anyone else",
    "\\bbro\\b": "brother",
    "\\bsis\\b": "sister",
    "\\bfwb\\b": "friends with benefits",
    "\\bfomo\\b": "fear of missing out",
    "\\birl\\b": "in real life",
    "\\bnsfw\\b": "not safe for work",
    "\\bover\\b": "more than",
    "\\bunder\\b": "less than",
    "\\bslay\\b": "perform excellently",
    "\\bsmh\\b": "shaking my head",
    "\\bngl\\b": "not gonna lie",
    "\\bafaik\\b": "as far as I know",
    "\\bbruh\\b": "bro",
    "\\bflex\\b": "show off",
    "\\bchill\\b": "relax",
    "\\bbet\\b": "I agree or okay",
    "\\bfr\\b": "for real",
    "\\bgod\\b": "god",
    "\\bdm\\b": "direct message",
    "\\bthot\\b": "that hoe over there",
    "\\bcringe\\b": "embarrassing",
    "\\bhype\\b": "exciting",
    "\\bclout\\b": "influence",
    "\\bthx\\b": "thanks",
    "\\bseggs\\b": "eggs",
    "\\byeet\\b": "throw away or excitement",
    "\\bstan\\b": "to be a devoted fan of",
    "\\bsksksk\\b": "lol",
    "\\bbussin\\b": "very good, tasty",
    "\\bslaps\\b": "good music or something",
    "\\boof\\b": "smelly, bad",
    "\\bbig yikes\\b": "big mistake",
    "\\bgoat\\b": "greatest of all time",
    "\\bcap\\b": "lie",
    "\\bno cap\\b": "no lie",
    "\\bbig mood\\b": "totally agree",
    "\\bbeef\\b": "conflict",
    "\\bmood\\b": "feeling",
    "\\bsus\\b": "suspicious",
    "\\bwoke\\b": "socially aware",
    "\\bslime\\b": "friend",
    "\\bspilling tea\\b": "gossiping",
    "\\btea\\b": "gossip",
    "\\bshade\\b": "insult",
    "\\bfrfr\\b": "for real, for real",
    "\\bnope\\b": "no",
    "\\bya\\b": "yes",
    "\\bbtw\\b": "by the way",
    "\\bshook\\b": "surprised or shaken",
    "\\bslay\\b": "do well or perform",
    "\\btea\\b": "gossip",
    "\\bwya\\b": "where you at?",
    "\\bsksk\\b": "laughing, often in a mocking tone",
    "\\bnvm\\b": "never mind",
    "\\bfam\\b": "family",
    "\\bdm\\b": "direct message",
    "\\bdrip\\b": "stylish, cool",
    "\\bstan\\b": "devoted fan",
    "\\bsmh\\b": "shaking my head",
    "\\bnoob\\b": "beginner or unskilled",
    "\\bglow up\\b": "improve appearance or style",
    "\\bship\\b": "to support a romantic pairing",
    "\\bvibe\\b": "mood or feeling",
    "\\bflex\\b": "to show off",
    "\\bsavage\\b": "a tough or hardcore person",
    "\\bclout\\b": "fame",
    "\\bfit\\b": "outfit",
    "\\bslaps\\b": "good music",
    "\\bbruh\\b": "dude",
    "\\bfinesse\\b": "to pull off with skill or style",
    "\\bbae\\b": "before anyone else",
    "\\bmoonwalking\\b": "acting nonchalant in a tough situation",
    "\\bhru\\b": "how are you"
  };
  let corrected = input.toLowerCase();
  corrected = corrected.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'\[\]]/g, "");
  for (const [pattern, replacement] of Object.entries(informalToFormal)) {
    const regex = new RegExp(pattern, "gi");
    corrected = corrected.replace(regex, replacement);
  }
  const finalCorrected = corrected.replace(/\s+/g, ' ').trim();
  return finalCorrected;
}
function getMathResponse() {
const mathResponses = [
  "The answer is ",
  "That would be ",
  "It's ",
  "Calculating... it's ",
  "After doing the math, I found it's ",
  "The result is ",
  "It's equal to ",
  "The solution is ",
  "I computed it to be ",
];
return mathResponses[Math.floor(Math.random() * fallbacks.length)];
}
const numberWords = [
  "zero","one","two","three","four","five","six","seven","eight","nine",
  "ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen",
  "seventeen","eighteen","nineteen","twenty"
];
const operatorWords = ["plus","minus","times","multiplied by","divided by"];
function hasMathQuestion(input) {
  const lower = input.toLowerCase();
  const mathPattern = /(\d+|\+|\-|\*|\/)/;
  if (mathPattern.test(lower)) return true;
  if (numberWords.some(word => lower.includes(word))) return true;
  if (operatorWords.some(word => lower.includes(word))) return true;
  const questionPhrases = ["how many","what is","whats","calculate","solve"];
  if (questionPhrases.some(phrase => lower.includes(phrase))) return true;
  return false;
}
const numberWordsToNumber = {
  zero: 0, one: 1, two: 2, three: 3, four: 4, five: 5,
  six: 6, seven: 7, eight: 8, nine: 9, ten: 10,
  eleven: 11, twelve: 12, thirteen: 13, fourteen: 14,
  fifteen: 15, sixteen: 16, seventeen: 17, eighteen: 18,
  nineteen: 19, twenty: 20
};
function wordsToNumbers(str) {
  const words = str.toLowerCase().split(/\b/);
  return words.map(word => numberWordsToNumber[word] !== undefined ? numberWordsToNumber[word] : word).join('');
}
function wordsToOperators(str) {
  return str
    .replace(/\bplus\b/g, '+')
    .replace(/\bminus\b/g, '-')
    .replace(/\btimes\b|\bmultiplied by\b/g, '*')
    .replace(/\bdivided by\b/g, '/');
}
function solveMathFromString(input) {
  let sanitized = input.toLowerCase().replace(/what('?s| is)?/g, '').replace(/how many (does|do) .* have\??/g, '');
  sanitized = wordsToNumbers(sanitized);
  sanitized = wordsToOperators(sanitized);
  sanitized = sanitized.replace(/[^0-9+\-*/().]/g, '');
  try {
    const result = Function(`return ${sanitized}`)();
    return result;
  } catch (err) {
    return "Couldn't parse math from the input.";
  }
}
async function getAnswer(query) {
  if (!query) {
    throw new Error("Please provide a search term.");
  }
  const searchEndpoint = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&origin=*`;
  try {
    const searchResponse = await fetch(searchEndpoint);
    const searchData = await searchResponse.json();
    if (searchData.query.search.length === 0) {
      return "No results found.";
    }
    const firstResult = searchData.query.search[0];
    const pageId = firstResult.pageid;
    const extractEndpoint = `https://en.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=true&explaintext=true&pageids=${pageId}&format=json&origin=*`;
    const extractResponse = await fetch(extractEndpoint);
    const extractData = await extractResponse.json();
    const page = extractData.query.pages[pageId];
    return page.extract || "No summary available.";
  } catch (error) {
    console.error("Error fetching answer:", error);
    return "Error fetching data from Wikipedia.";
  }
}
function extractImportant(text) {
  const stopwords = new Set([
    "what","is","a","the","your","to","how","of","in","on","at","for","and","do","does","did",
    "are","am","was","were","can","you","i","we","they","it"
  ]);
  if (devFlag === true) {
  console.log(`extracted: ${text.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(w => w && !stopwords.has(w))}`);
  }
  return text
    .toLowerCase()
    .replace(/[^a-z\s]/g, "")
    .split(/\s+/)
    .filter(w => w && !stopwords.has(w));
}
    function tagWords(text) {
      console.log("Tagging words in text: " + text);
      let doc = nlp(text);
      return doc.json()[0].terms.map(term => ({
        word: term.text,
        tag: term.tags[0] || "Unknown"
      }));
    }
async function getImage(query) {
  console.log("Fetching image for query: " + query);
  const accessKey = 'l9PkR9cuhWi4XRxJdgI0g8O67ioPS34QutHXugWX11Y';
  const url = `https://api.unsplash.com/search/photos?query=${encodeURIComponent(query)}&client_id=${accessKey}&per_page=1`;
  try {
    console.log("Sending request to Unsplash API: " + url);
    const res = await fetch(url).then(r => r.json());
    console.log("Image response from Unsplash: " + JSON.stringify(res));
    if (res.results && res.results.length > 0) {
      console.log("Image found: " + res.results[0].urls.regular);
      return res.results[0].urls.regular;
    } else {
      console.log("No image found for: " + query);
      return null;
    }
  } catch (e) {
    console.error("Error fetching image from Unsplash: " + e);
    return null;
  }
}
function processJSFixOnce(codeIn, errorLogIn) {
  let fixed = codeIn.split('\n');
  const messages = [];
  let changes = 0;
  let localErrorLog = errorLogIn;
  if (!localErrorLog || /^\s*(?:\(none\)|none)\s*$/i.test(localErrorLog)) {
    let generated = '';
    const openers = { '(': 0, '{': 0, '[': 0 };
    const closers = { ')': 0, '}': 0, ']': 0 };
    for (let i = 0; i < fixed.length; i++) {
      const line = fixed[i];
      for (let ch of line) {
        if (openers.hasOwnProperty(ch)) openers[ch]++;
        if (closers.hasOwnProperty(ch)) closers[ch]++;
      }
      const quoteCount = ((line.match(/"/g) || []).length + (line.match(/'/g) || []).length);
      if (quoteCount % 2 !== 0) generated += `Unterminated string at line ${i+1} column ${line.length}\n`;
      if (/[^;{}\s]$/.test(line)) generated += `missing ; at line ${i+1} column ${line.length+1}\n`;
    }
    if (openers['('] > closers[')']) generated += `missing ) at line ${fixed.length} column ${fixed[fixed.length-1].length+1}\n`;
    if (openers['{'] > closers['}']) generated += `missing } at line ${fixed.length} column ${fixed[fixed.length-1].length+1}\n`;
    if (openers['['] > closers[']']) generated += `missing ] at line ${fixed.length} column ${fixed[fixed.length-1].length+1}\n`;
    localErrorLog = generated.trim();
  }
  const lines = (localErrorLog || '').split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const refVarsToDeclare = new Set();
  for (const l of lines) {
    let m = l.match(/Unexpected reserved word '?([^' ]*)'? at line (\d+) column (\d+)/i);
    if (m) {
      const word = m[1], ln = parseInt(m[2],10)-1, col = parseInt(m[3],10)-1;
      if (fixed[ln] !== undefined && word && fixed[ln].slice(col, col+word.length) === word) {
        fixed[ln] = fixed[ln].slice(0,col) + fixed[ln].slice(col+word.length);
        messages.push(`Removed unexpected reserved word '${word}' at line ${ln+1}, column ${col+1}`);
        changes++;
      }
      continue;
    }
    m = l.match(/Unexpected newline at line (\d+) column (\d+)/i);
    if (m) {
      const ln = parseInt(m[1],10)-1;
      if (fixed[ln] !== undefined && fixed[ln+1] !== undefined) {
        fixed[ln] = fixed[ln] + ' ' + fixed[ln+1];
        fixed.splice(ln+1,1);
        messages.push(`Joined lines ${ln+1} and ${ln+2} to fix unexpected newline`);
        changes++;
      }
      continue;
    }
    m = l.match(/(Unterminated string|Unexpected end of string) at line (\d+) column (\d+)/i);
    if (m) {
      const ln = parseInt(m[2],10)-1;
      if (fixed[ln] !== undefined) {
        fixed[ln] = fixed[ln] + '"';
        messages.push(`Closed unterminated string at line ${ln+1}`);
        changes++;
      }
      continue;
    }
    m = l.match(/missing ([^ ]+) at line (\d+) column (\d+)/i);
    if (m) {
      const token = m[1], ln = parseInt(m[2],10)-1, col = parseInt(m[3],10)-1;
      if (fixed[ln] !== undefined) {
        fixed[ln] = fixed[ln].slice(0,col) + token + fixed[ln].slice(col);
        messages.push(`Inserted missing '${token}' at line ${ln+1}, column ${col+1}`);
        changes++;
      }
      continue;
    }
    m = l.match(/Unexpected token ILLEGAL at line (\d+) column (\d+)/i);
    if (m) {
      const ln = parseInt(m[1],10)-1, col = parseInt(m[2],10)-1;
      if (fixed[ln] !== undefined) {
        fixed[ln] = fixed[ln].slice(0,col) + fixed[ln].slice(col+1);
        messages.push(`Removed illegal character at line ${ln+1}, column ${col+1}`);
        changes++;
      }
      continue;
    }
    m = l.match(/Assignment to constant variable '?([^' ]*)'? at line (\d+) column (\d+)/i);
    if (m) {
      const varName = m[1], ln = parseInt(m[2],10)-1;
      if (fixed[ln] !== undefined) {
        fixed[ln] = fixed[ln].replace(/\bconst\s+"?([a-zA-Z_$][a-zA-Z0-9_$]*)"?/, 'let $1');
        messages.push(`Changed 'const' to 'let' for variable '${varName}' at line ${ln+1}`);
        changes++;
      }
      continue;
    }
    m = l.match(/Unexpected token ([^ ]+) at line (\d+) column (\d+)/i);
    if (m) {
      const token = m[1], ln = parseInt(m[2],10)-1, col = parseInt(m[3],10)-1;
      if (fixed[ln] !== undefined && fixed[ln].slice(col, col + token.length) === token) {
        fixed[ln] = fixed[ln].slice(0, col) + fixed[ln].slice(col + token.length);
        messages.push(`Removed unexpected token '${token}' at line ${ln+1}, column ${col+1}`);
        changes++;
      }
      continue;
    }
    m = l.match(/Cannot access '([a-zA-Z_$][a-zA-Z0-9_$]*)' before initialization/i);
    if (m) {
      const varName = m[1];
      if (!fixed[0].includes(`let ${varName}`)) {
        fixed.unshift(`let ${varName};`);
        messages.push(`Declared '${varName}' at top to avoid temporal dead zone`);
        changes++;
      }
      continue;
    }
    m = l.match(/([a-zA-Z_$][a-zA-Z0-9_$]*) is not defined at line (\d+) column (\d+)/i);
    if (m) {
      const varName = m[1];
      refVarsToDeclare.add(varName);
      continue;
    }
    m = l.match(/Unexpected (identifier|number|string) '?([^' ]*)'? at line (\d+) column (\d+)/i);
    if (m) {
      const type = m[1], token = m[2], ln = parseInt(m[3],10)-1, col = parseInt(m[4],10)-1;
      if (fixed[ln] !== undefined) {
        if (token && fixed[ln].slice(col, col + token.length) === token) {
          fixed[ln] = fixed[ln].slice(0, col) + fixed[ln].slice(col + token.length);
          messages.push(`Removed unexpected ${type} '${token}' at line ${ln+1}, column ${col+1}`);
          changes++;
        } else {
          fixed[ln] = fixed[ln].replace(/\b\w+\b/, '');
          messages.push(`Removed unexpected ${type} at line ${ln+1}, column ${col+1}`);
          changes++;
        }
      }
      continue;
    }
    if (/Unexpected end of JSON input/i.test(l)) {
      continue;
    }
    if (/Maximum call stack size exceeded/i.test(l)) {
      messages.push('Warning: Maximum call stack size exceeded. Consider refactoring recursive functions.');
      continue;
    }
  }
  if (refVarsToDeclare.size > 0) {
    const declared = Array.from(refVarsToDeclare).join(', ');
    fixed.unshift('let ' + declared + ';');
    messages.push(`Declared missing variable(s): ${declared}`);
    changes++;
  }
  if (/Unexpected end of input/i.test(localErrorLog) || /Unexpected end of JSON input/i.test(localErrorLog)) {
    const openers = { '{': 0, '[': 0, '(': 0 };
    const closers = { '}': 0, ']': 0, ')': 0 };
    for (let line of fixed) for (let c of line) {
      if (openers.hasOwnProperty(c)) openers[c]++;
      if (closers.hasOwnProperty(c)) closers[c]++;
    }
    const toClose = [
      ...Array(Math.max(0, openers['{'] - closers['}'])).fill('}'),
      ...Array(Math.max(0, openers['['] - closers[']'])).fill(']'),
      ...Array(Math.max(0, openers['('] - closers[')'])).fill(')')
    ];
    if (toClose.length > 0) {
      fixed[fixed.length - 1] += toClose.join('');
      messages.push(`Added closing: ${toClose.join(' ')}`);
      changes++;
    }
  }
  if (!changes && localErrorLog && /missing\s*\)|missing\s*\)\s*after\s*argument\s*list|unexpected end of input/i.test(localErrorLog)) {
    const openers = { '{': 0, '[': 0, '(': 0 };
    const closers = { '}': 0, ']': 0, ')': 0 };
    for (let line of fixed) for (let c of line) {
      if (openers.hasOwnProperty(c)) openers[c]++;
      if (closers.hasOwnProperty(c)) closers[c]++;
    }
    const neededParens = Math.max(0, openers['('] - closers[')']);
    const neededBraces = Math.max(0, openers['{'] - closers['}']);
    const neededBrackets = Math.max(0, openers['['] - closers[']']);
    const toClose = [];
    if (neededParens > 0) toClose.push(...Array(neededParens).fill(')'));
    if (neededBrackets > 0) toClose.push(...Array(neededBrackets).fill(']'));
    if (neededBraces > 0) toClose.push(...Array(neededBraces).fill('}'));
    if (toClose.length > 0) {
      fixed[fixed.length - 1] = fixed[fixed.length - 1] + toClose.join('');
      messages.push(`Heuristic: added closing tokens: ${toClose.join(' ')}`);
      changes++;
    }
  }
  return { fixedCode: fixed.join('\n'), messages, changes, errorLog: localErrorLog };
}
function fixJSCode(code, errorLog) {
  let currentCode = code;
  let currentErrorLog = errorLog || '';
  const aggMessages = [];
  let lastErrorLog = currentErrorLog;
  for (let i = 0; i < 5; i++) {
    const res = processJSFixOnce(currentCode, currentErrorLog);
    aggMessages.push(...res.messages);
    currentCode = res.fixedCode;
    lastErrorLog = res.errorLog;
    if (!res.changes) break;
    currentErrorLog = '';
  }
  const fixedCode = currentCode;
  let report = "<b>JS Fixer:</b><br>";
  report += "<b>Error Log:</b><br><pre style='white-space: pre-wrap; color:#e74c3c;'>" + (lastErrorLog ? lastErrorLog.replace(/</g, "&lt;").replace(/>/g, "&gt;") : '(none)') + "</pre>";
  report += "<pre style='white-space: pre-wrap;'>" + fixedCode.replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</pre>";
  if (aggMessages.length > 0) {
    report += "<b>Fixes applied:</b><br><ul>";
    aggMessages.forEach(m => report += `<li>${m}</li>`);
    report += "</ul>";
  } else {
    report += "<i>No recognized fixable instructions found in error log.</i>";
  }
  return report;
}
function runJSInSandbox(code, timeoutMs = 2000) {
  return new Promise((resolve) => {
    const id = 'sandbox_' + Math.random().toString(36).slice(2);
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    iframe.sandbox = 'allow-scripts';
    try { iframe.dataset.code = btoa(unescape(encodeURIComponent(code))); } catch (e) { iframe.dataset.code = btoa(code); }
    const messages = [];
    function onMessage(e) {
      const data = e.data || {};
      if (data && data.__runJSSandbox && data.id === id) {
        const p = data.payload;
        if (!p) return;
        if (p.type === 'console') messages.push({type: p.level, args: p.args});
        if (p.type === 'error') messages.push({type: 'error', message: p.message, stack: p.stack, url: p.url, line: p.line, col: p.col});
        if (p.type === 'done') {
          cleanup();
          const errors = messages.filter(m=>m.type==='error');
          const errorLog = errors.map(er => (er.message || '') + (er.line?` at ${er.line}:${er.col}`:'') + (er.stack?`\n${er.stack}`:'')).join('\n');
          resolve({ console: messages.filter(m=>m.type!=='error'), errorLog });
        }
      }
    }
    function cleanup() {
      window.removeEventListener('message', onMessage);
      if (iframe && iframe.parentNode) iframe.parentNode.removeChild(iframe);
      clearTimeout(killTimer);
    }
    window.addEventListener('message', onMessage);
    const srcdoc = `<!doctype html><html><body><script>
      (function(){
        const id='${id}';
        function send(obj){ parent.postMessage({__runJSSandbox:true,id:id,payload:obj}, '*'); }
        ['log','warn','error','info'].forEach(k=>{ const orig=console[k]; console[k]=function(){ try{ send({type:'console', level:k, args:Array.from(arguments)}); }catch(e){}; orig.apply(console, arguments); }; });
        window.onerror = function(msg, url, line, col, err){ send({type:'error', message: String(msg), url, line, col, stack: err && err.stack}); };
        window.addEventListener('unhandledrejection', function(e){ send({type:'error', message:'UnhandledRejection: '+(e.reason && e.reason.message?e.reason.message: String(e.reason)), stack: e.reason && e.reason.stack}); });
        try {
          const coded = '${iframe.dataset.code || ''}';
          let userCode = '';
          try { userCode = decodeURIComponent(escape(atob(coded))); } catch(e) { try{ userCode = atob(coded); }catch(e2){ userCode=''; } }
          if(userCode) {
            (0,eval)(userCode);
          }
          send({type:'done'});
        } catch (e) { send({type:'error', message: e.message, stack: e.stack}); }
      })();
    <\/script></body></html>`;
    iframe.srcdoc = srcdoc;
    document.body.appendChild(iframe);
    const killTimer = setTimeout(()=>{
      window.removeEventListener('message', onMessage);
      if (iframe && iframe.parentNode) iframe.parentNode.removeChild(iframe);
      const errors = messages.filter(m=>m.type==='error');
      const errorLog = errors.map(er => (er.message || '') + (er.stack?`\n${er.stack}`:'')).join('\n') || 'Timeout or no output';
      resolve({ console: messages.filter(m=>m.type!=='error'), errorLog });
    }, timeoutMs);
  });
}
async function autoRunAndFix(code, maxIterations = 5, runTimeout = 2000) {
  let currentCode = code;
  const aggMessages = [];
  let lastRuntimeLog = '';
  for (let i = 0; i < maxIterations; i++) {
    let syntaxErrorMsg = '';
    try {
      new Function(currentCode);
    } catch (e) {
      syntaxErrorMsg = (e && e.message) ? String(e.message) : 'Syntax error';
    }
    if (syntaxErrorMsg) {
      lastRuntimeLog = syntaxErrorMsg;
      const res = processJSFixOnce(currentCode, lastRuntimeLog);
      aggMessages.push(...res.messages.map(m => `Pass ${i+1}: ${m}`));
      if (!res.changes) break;
      currentCode = res.fixedCode;
      continue;
    }
    const runRes = await runJSInSandbox(currentCode, runTimeout);
    lastRuntimeLog = runRes.errorLog || '';
    if (!lastRuntimeLog) {
      break;
    }
    const res = processJSFixOnce(currentCode, lastRuntimeLog);
    aggMessages.push(...res.messages.map(m => `Pass ${i+1}: ${m}`));
    if (!res.changes) break;
    currentCode = res.fixedCode;
  }
  let report = "<b>Fixed Code:</b><br>";
  report += "<b>Last Runtime Error Log:</b><br><pre style='white-space: pre-wrap; color:#e74c3c;'>" + (lastRuntimeLog ? lastRuntimeLog.replace(/</g, "&lt;").replace(/>/g, "&gt;") : '(none)') + "</pre>";
  report += "<pre style='white-space: pre-wrap;'>" + currentCode.replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</pre>";
  if (aggMessages.length > 0) {
    report += "<b>Fixes applied:</b><br><ul>";
    aggMessages.forEach(m => report += `<li>${m}</li>`);
    report += "</ul>";
  } else {
    report += "<i>No automated fixes applied.</i>";
  }
  return report;
}
function renderBubble(text) {
  const bubble = el('div', { class: 'bubble' });
  const imageMatch = /^Image: (https?:\/\/\S+)/.exec(text);
  if (imageMatch) {
    const url = imageMatch[1];
    const imgEl = el('img', {src: url, alt: 'Image', style:'max-width:100%; border-radius:12px; display:block;'});
    bubble.appendChild(el('p', {}, `Here's an image:`));
    bubble.appendChild(imgEl);
  } else {
    bubble.appendChild(renderMarkdown(text));
  }
  return bubble;
}
let lastBotKey = null;
let pendingMessageKey = null;
let replyTargetIndex = null;
let awaitingAnswer = false; 
function levenshteinDistance(a, b) {
  const dp = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) dp[i][0] = i;
  for (let j = 0; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
    }
  }
  return dp[a.length][b.length];
}
async function findClosestKey(input, dataset, synonyms, promptTone = null, desiredType = null) {
  input = String(input || '').toLowerCase().trim();
  const myAbortToken = thinkAbortToken;
  const rawInput = input;
  let tagged = [];
  try { if (typeof tagWords === 'function') tagged = tagWords(rawInput) || []; } catch (e) { tagged = []; }
  const adjSet = new Set(tagged.filter(t=>/adject/i.test(t.tag)).map(t=>String(t.word||'').toLowerCase()));
  const nounSet = new Set(tagged.filter(t=>/noun/i.test(t.tag)).map(t=>String(t.word||'').toLowerCase()));
  const verbSet = new Set(tagged.filter(t=>/verb/i.test(t.tag)).map(t=>String(t.word||'').toLowerCase()));
  const rawTokens = rawInput.split(/\s+/).filter(Boolean).map(t=>t.toLowerCase());
  const filteredTokens = rawTokens.filter(t => !adjSet.has(t));
  if (filteredTokens.length > 0) input = filteredTokens.join(' ');
  for (const k in dataset) {
    if (!k) continue;
    if (isBlocked(k)) continue;
    if (k.toLowerCase() === input) {
  console.log(`findClosestKey -> exact match to key "${k}"`);
  clearThinkStatus();
  return k;
    }
  }
  const keyMeta = [];
  for (const k in dataset) {
    if (!k) continue;
    if (isBlocked(k)) continue;
    const keyLower = k.toLowerCase();
    let keyTone = null;
    try {
      keyTone = detectTone(k) || null;
      if (!keyTone && dataset[k] && dataset[k].responses) {
        const sample = Array.isArray(dataset[k].responses) ? dataset[k].responses.slice(0,3).join(' ') : '';
        keyTone = detectTone(sample) || keyTone;
      }
    } catch (e) { keyTone = null; }
    let keyType = null;
    try {
      keyType = detectType(k) || null;
      if (!keyType && dataset[k] && dataset[k].responses) {
        const sample = Array.isArray(dataset[k].responses) ? dataset[k].responses.slice(0,3).join(' ') : '';
        keyType = detectType(sample) || keyType;
      }
    } catch (e) { keyType = null; }
    keyMeta.push({ key: k, keyLower, keyTone, keyType, len: k.length });
  }
  const _esc = s => String(s).replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
  let effectiveKeyMeta = keyMeta;
  try {
    if (thinkMode) {
      const important = Array.isArray(extractImportant) ? extractImportant(input) : (typeof extractImportant === 'function' ? extractImportant(input) : []);
      if (Array.isArray(important) && important.length > 0) {
        const words = important.map(w => String(w || '').toLowerCase()).filter(Boolean);
        if (words.length > 0) {
          effectiveKeyMeta = keyMeta.filter(km => {
            for (const w of words) {
              try {
                const re = new RegExp('\\b' + _esc(w) + '\\b', 'i');
                if (re.test(km.keyLower)) return true;
              } catch (e) {}
            }
            return false;
          });
          if (!effectiveKeyMeta || effectiveKeyMeta.length === 0) effectiveKeyMeta = keyMeta;
        }
      }
    }
  } catch (e) {
    effectiveKeyMeta = keyMeta;
  }
  const tokens = input.split(/\s+/).filter(Boolean);
  let replacements;
  if (desiredType === 'question') {
    replacements = tokens.map(t => [String(t).toLowerCase()]);
  } else {
    replacements = tokens.map(t => {
      const low = t.toLowerCase();
      const set = new Set([low]);
      if (synonyms && synonyms[low] && Array.isArray(synonyms[low])) {
        for (const s of synonyms[low]) {
          if (s && !isBlocked(s)) set.add(String(s).toLowerCase());
        }
      }
      return Array.from(set);
    });
  }
  const totalVariants = replacements.reduce((acc, r) => acc * Math.max(1, r.length), 1);
  const DEFAULT_MAX_VARIANTS = 500;
  const THINK_MAX_VARIANTS = 10000;
  const THINK_CHUNK = 10;
  const limit = thinkMode ? THINK_MAX_VARIANTS : DEFAULT_MAX_VARIANTS;
  function setThinkStatus(elapsedSec, percent) {
    try {
      const conv = currentConv();
      if (!conv) return;
      const idx = conv.messages.findIndex(m => m._thinkStatus);
      const text = `Thinking... (${Math.max(0, Math.floor(elapsedSec))}s, ${Math.max(0, Math.min(100, Math.floor(percent)))}%)`;
      if (idx >= 0) {
        conv.messages[idx].content = text;
        renderMessages();
        return;
      }
      conv.messages.push({ role: 'assistant', content: text, ts: Date.now(), _thinkStatus: true });
      persist();
      renderMessages();
    } catch (e) {}
  }
  function clearThinkStatus() {
    try {
      const conv = currentConv();
      if (!conv) return;
      const before = conv.messages.length;
      conv.messages = conv.messages.filter(m => !m._thinkStatus);
      if (conv.messages.length !== before) {
        persist(); renderMessages();
      }
    } catch (e) {}
  }
  if (totalVariants <= 1 || totalVariants > limit) {
    let bestKey = null;
    let bestScore = Infinity;
    for (const km of effectiveKeyMeta) {
      let distance = levenshteinDistance(input, km.keyLower);
      try {
        for (const n of Array.from(nounSet)) {
          if (!n) continue;
          const re = new RegExp('\\b' + _esc(n) + '\\b', 'i');
          if (re.test(km.keyLower)) { distance = Math.max(0, Math.floor(distance * 0.6) - 1); break; }
        }
        for (const v of Array.from(verbSet)) {
          if (!v) continue;
          const re2 = new RegExp('\\b' + _esc(v) + '\\b', 'i');
          if (re2.test(km.keyLower)) { distance = Math.max(0, Math.floor(distance * 0.8) - 1); break; }
        }
      } catch (e) {}
      if (promptTone && km.keyTone && promptTone === km.keyTone) distance = Math.max(0, Math.floor(distance * 0.6) - 1);
      if (desiredType && km.keyType && desiredType === km.keyType) distance = Math.max(0, Math.floor(distance * 0.5) - 1);
      let allowMatch = true;
      if (desiredType === 'question') {
        try {
          const impInput = (typeof extractImportant === 'function') ? extractImportant(input) : [];
          const impKey = (typeof extractImportant === 'function') ? extractImportant(km.keyLower) : [];
          const overlap = impInput.filter(w => impKey.includes(w));
          if (!overlap || overlap.length === 0) allowMatch = false;
        } catch (e) {  }
      }
      const maxAllowed = (desiredType === 'question') ? Math.max(0, Math.floor(km.len / 6)) : Math.max(1, Math.floor(km.len / 2));
      if (allowMatch && distance < bestScore && distance <= maxAllowed) {
        bestScore = distance; bestKey = km.key;
      }
    }
    if (bestKey) console.log(`findClosestKey -> selected "${bestKey}" (score=${bestScore}) [fallback] for input "${input}"`);
    else console.log(`findClosestKey -> no suitable key found [fallback] for input "${input}"`);
  clearThinkStatus();
  return bestKey;
  }
  const winCounts = Object.create(null);
  const scoreSums = Object.create(null);
  let generated = 0;
  const idxs = Array(replacements.length).fill(0);
  const lenses = replacements.map(r => Math.max(1, r.length));
  let done = false;
  function buildVariant() {
    return replacements.map((r, i) => r[idxs[i]] || r[0]).join(' ');
  }
  function advance() {
    for (let i = idxs.length - 1; i >= 0; i--) {
      idxs[i]++;
      if (idxs[i] < lenses[i]) return true;
      idxs[i] = 0;
    }
    return false;
  }
  const chunkSize = thinkMode ? THINK_CHUNK : Math.min(limit, 1000);
  const startMs = Date.now();
  const totalToProcess = Math.max(1, Math.min(totalVariants, limit));
  while (!done && generated < limit) {
    if (myAbortToken !== thinkAbortToken) {
      console.log('findClosestKey -> aborted by user');
      clearThinkStatus();
      return null;
    }
    const batchEnd = Math.min(limit, generated + chunkSize);
    for (; generated < batchEnd; generated++) {
      if (myAbortToken !== thinkAbortToken) {
        console.log('findClosestKey -> aborted by user');
        clearThinkStatus();
        return null;
      }
      const variant = buildVariant();
      try {
        const elapsedSec = Math.floor((Date.now() - startMs) / 1000);
        const processed = generated + 1;
        const pct = Math.floor((processed / totalToProcess) * 100);
        setThinkStatus(elapsedSec, pct);
      } catch (e) {}
      let winner = null;
      let winnerScore = Infinity;
      for (const km of effectiveKeyMeta) {
        let distance = levenshteinDistance(variant, km.keyLower);
        try {
          for (const n of Array.from(nounSet)) {
            if (!n) continue;
            const re = new RegExp('\\b' + _esc(n) + '\\b', 'i');
            if (re.test(km.keyLower)) { distance = Math.max(0, Math.floor(distance * 0.6) - 1); break; }
          }
          for (const v of Array.from(verbSet)) {
            if (!v) continue;
            const re2 = new RegExp('\\b' + _esc(v) + '\\b', 'i');
            if (re2.test(km.keyLower)) { distance = Math.max(0, Math.floor(distance * 0.8) - 1); break; }
          }
        } catch (e) {}
        if (promptTone && km.keyTone && promptTone === km.keyTone) distance = Math.max(0, Math.floor(distance * 0.6) - 1);
        if (desiredType && km.keyType && desiredType === km.keyType) distance = Math.max(0, Math.floor(distance * 0.5) - 1);
        let allowVarMatch = true;
        if (desiredType === 'question') {
          try {
            const impVariant = (typeof extractImportant === 'function') ? extractImportant(variant) : [];
            const impKey = (typeof extractImportant === 'function') ? extractImportant(km.keyLower) : [];
            const overlapVar = impVariant.filter(w => impKey.includes(w));
            if (!overlapVar || overlapVar.length === 0) allowVarMatch = false;
          } catch (e) {}
        }
        const maxAllowedVar = (desiredType === 'question') ? Math.max(0, Math.floor(km.len / 6)) : Math.max(1, Math.floor(km.len / 2));
        if (allowVarMatch && distance < winnerScore && distance <= maxAllowedVar) {
          winnerScore = distance; winner = km.key;
        }
      }
      if (winner) {
        winCounts[winner] = (winCounts[winner] || 0) + 1;
        scoreSums[winner] = (scoreSums[winner] || 0) + winnerScore;
      }
      if (!advance()) { done = true; break; }
    }
    await new Promise(r => setTimeout(r, 0));
  }
  clearThinkStatus();
  let chosen = null;
  let bestWins = -1;
  let bestAvg = Infinity;
  for (const k of Object.keys(winCounts)) {
    const wins = winCounts[k];
    const avg = (scoreSums[k] || 0) / wins;
    if (wins > bestWins || (wins === bestWins && avg < bestAvg)) {
      chosen = k; bestWins = wins; bestAvg = avg;
    }
  }
  if (chosen) {
    console.log(`findClosestKey -> chosen "${chosen}" wins=${bestWins} avgScore=${(bestAvg||0).toFixed(2)} variantsExamined=${generated}`);
  } else {
    console.log(`findClosestKey -> no winner after examining ${generated} variants for input "${input}"`);
  }
  return chosen;
}
function detectTone(text) {
  const angryWords = ["hate", "stupid", "idiot", "mad", "angry", "annoying", "dumb", "shut up", "useless", "terrible", "worst", "awful", "sucks", "f***", "fuk", "fml", "i hate you", "i'm mad", "i am mad", "i am angry", "i'm angry"];
  const excitedWords = ["excited", "yay", "awesome", "amazing", "so happy", "can't wait", "lets go", "let's go", "woo", "wooo", "so cool", "so fun", "hyped", "im so excited", "i'm so excited", "this is great", "so excited", "incredible", "fantastic", "love this", "i love this", "i love you"];
  const lower = text.toLowerCase();
  const isAllCaps = text === text.toUpperCase() && text.length > 4;
  const manyExclaim = (text.match(/!{2,}/g) || []).length > 0;
  const hasAngryWord = angryWords.some(w => lower.includes(w));
  const hasExcitedWord = excitedWords.some(w => lower.includes(w));
  if (hasAngryWord) return 'angry';
  if (hasExcitedWord && (isAllCaps || manyExclaim)) return 'excited';
  if ((isAllCaps || manyExclaim) && !hasAngryWord) {
    if (hasExcitedWord) return 'excited';
    if (isAllCaps && !hasExcitedWord) return 'angry';
  }
  return null;
}
function detectType(text) {
  if (!text || typeof text !== 'string') return 'normal';
  const t = text.trim();
  const lower = t.toLowerCase();
  const interrogatives = ['how to', 'how do', 'how can', 'what is', 'what are', 'why', 'where', 'who', 'when', 'which', 'how', "what's", 'whats'];
  if (/[?]\s*$/.test(t)) return 'question';
  for (const q of interrogatives) {
    if (lower.startsWith(q)) return 'question';
  }
  const instructionStarts = ['do ', 'please ', 'make ', 'create ', 'build ', 'write ', 'generate ', 'implement ', 'add ', 'remove ', 'delete ', 'update ', 'install ', 'run ', 'start ', 'stop ', 'convert ', 'refactor ', 'translate ', 'help me', 'send ', 'provide ', 'do:' ];
  for (const s of instructionStarts) {
    if (lower.startsWith(s)) return 'instruction';
  }
  return 'normal';
}
function getBlocklist() {
  try {
    const raw = localStorage.getItem('blocklist_v1');
    if (!raw) return [ 'sex', 'xxx', 'porn', 'buy drugs', 'naked', 'i will hurt you', 'how to hack', 'kill you' ];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(s => String(s).toLowerCase()) : [];
  } catch (e) { return [ 'sex', 'xxx', 'porn', 'buy drugs', 'naked', 'i will hurt you', 'how to hack', 'kill you' ]; }
}
function setBlocklist(arr) { localStorage.setItem('blocklist_v1', JSON.stringify(arr || [])); }
function isBlocked(text) {
  if (!text) return false;
  const t = String(text).toLowerCase();
  const bl = getBlocklist();
  for (const w of bl) {
    if (!w) continue;
    const safe = w.replace(/[-/\\^$*+?.()|[\]{}]/g, '\\$&');
    const re = new RegExp('\\b' + safe + '\\b', 'i');
    if (re.test(t) || (t.includes(w) && /[^a-z0-9]/i.test(w))) return true;
  }
  return false;
}
async function handleInstructionSync(instr) {
  const lower = instr.trim().toLowerCase();
  const fixMatch = instr.match(/fix this:\s*([\s\S]+)/i);
  if (fixMatch) {
    const codeToFix = fixMatch[1].trim() || (currentConv() && [...currentConv().messages].reverse().find(m=>m.role==='user')?.content);
    if (!codeToFix) return 'No code found to fix.';
    const report = await autoRunAndFix(codeToFix, 5, 2000);
    return report;
  }
  if (/^fix this\b/i.test(instr) && !/fix this:\s*/i.test(instr)) {
    const lastUser = currentConv() && [...currentConv().messages].reverse().find(m=>m.role==='user');
    if (!lastUser) return 'No recent user message found to fix.';
    const report = await autoRunAndFix(lastUser.content, 5, 2000);
    return report;
  }
  const imgMatch = instr.match(/(?:make an image for|make an image of|make image for|create an image for|create an image of|generate an image for|generate an image of)\s*:?\s*(.+)/i);
  if (imgMatch) {
    const query = imgMatch[1].trim();
    if (!query) return 'What should I make an image of?';
    const url = await getImage(query);
    if (url) return `Image: ${url}`;
    return `Sorry, I couldn't create an image for "${query}".`;
  }
  if (/^(new|create)\b/.test(lower) || /\bnew chat\b/.test(lower)) {
    const conv = createConversation();
    currentId = conv.id; persist(); hydrate();
    return 'Created a new chat.';
  }
  if (/clear all|delete all|remove all/.test(lower)) {
    const ok = await showConfirm('Clear all conversations?');
    if (!ok) return 'Cancelled clearing conversations.';
    conversations = []; currentId = createConversation().id; persist(); hydrate();
    return 'All conversations cleared.';
  }
  if (/export/.test(lower)) {
    document.getElementById('exportBtn').click();
    return 'Exported conversations to a JSON download.';
  }
  if (/image (on|off|toggle)|toggle image|image toggle/.test(lower)) {
    imageMode = !imageMode;
    document.getElementById('imageToggle').classList.toggle('primary', imageMode);
    return `Image mode ${imageMode ? 'enabled' : 'disabled'}.`;
  }
  if (/jsfix (on|off|toggle)|toggle jsfix|js fix toggle/.test(lower)) {
    jsFixMode = !jsFixMode;
    jsFixToggle.classList.toggle('primary', jsFixMode);
    return `JS Fix mode ${jsFixMode ? 'enabled' : 'disabled'}.`;
  }
  if (/set theme to (dark|light)/.test(lower) || /theme (dark|light)/.test(lower)) {
    const m = lower.match(/(dark|light)/);
    if (m) {
      if (m[1] === 'light') document.body.classList.add('light');
      else document.body.classList.remove('light');
      localStorage.setItem('theme', m[1]);
      renderMessages();
      return `Theme set to ${m[1]}.`;
    }
  }
  let titleMatch = instr.match(/^(?:set )?(?:title|rename|name)[:\s]+(.+)$/i);
  if (titleMatch) {
    const newTitle = titleMatch[1].trim();
    const conv = currentConv();
    if (conv) {
      conv.title = newTitle;
      persist(); hydrate();
      return `Conversation renamed to "${newTitle}".`;
    }
    return 'No conversation found to rename.';
  }
  if (/regenerate|regen|repeat last|try again/.test(lower)) {
    const conv = currentConv();
    for (let i = conv.messages.length - 1; i >= 0; i--) {
      if (conv.messages[i].role === 'assistant') { regenerateAt(i); return 'Regenerating the last assistant message...'; }
    }
    return 'No assistant message found to regenerate.';
  }
  if (/delete (this )?(chat|conversation)|remove (this )?(chat|conversation)/.test(lower)) {
    const ok = await showConfirm('Delete this conversation?');
    if (!ok) return 'Cancelled deletion.';
    const conv = currentConv();
    if (conv) {
      conversations = conversations.filter(x => x.id !== conv.id);
      const next = conversations[0] || createConversation();
      currentId = next.id; persist(); hydrate();
      return 'Conversation deleted.';
    }
    return 'No conversation found to delete.';
  }
  return "I can try to follow some simple commands (create chat, set title, export, toggle modes, set theme, regenerate). For destructive actions like delete/clear, please confirm in the UI.";
}
function getCalmingPhrase() {
  const phrases = [
    "Let's take a deep breath.",
    "It's okay, I'm here to help.",
    "Let's stay calm and work through this.",
    "I understand you're upset.",
    "Let's try to solve this together.",
    "I'm here for you."
  ];
  return phrases[Math.floor(Math.random() * phrases.length)];
}
function getFallbackResponse() {
const fallbacks = [
  "Sorry, I didn't understand that.",
  "I'm not sure I follow.",
  "Hmm, I didn't get that.",
  "Sorry, I didn't catch that.",
  "I can't find a good answer for that right now.",
  "That doesn’t seem clear to me.",
  "I might be missing something here.",
  "I'm not certain about that one.",
  "That’s a bit unclear on my end.",
  "I don’t have an answer for that at the moment.",
  "That went over my head.",
  "I’m not sure what to do with that.",
  "That doesn’t look like something I can handle.",
  "I’m drawing a blank on that.",
  "That input doesn’t make sense to me.",
  "I don’t have information on that.",
  "That’s outside what I can provide right now.",
  "I can’t respond to that properly.",
  "That seems beyond my scope.",
  "I wasn’t able to process that.",
  "That doesn’t match anything I know.",
  "I don’t recognize that input.",
  "I can’t figure that out.",
  "That doesn’t compute for me.",
  "I couldn’t make sense of that.",
  "That slipped past me.",
  "I’m unable to handle that request.",
  "That doesn’t look valid to me.",
  "I didn’t follow that properly.",
  "I wasn’t able to interpret that."
];
  return fallbacks[Math.floor(Math.random() * fallbacks.length)];
}
async function generateBotMessage(userMessage) {
  const originalMsg = userMessage;
  userMessage = autocorrect(userMessage.toLowerCase().trim());
  let prefix = "";
  const tone = detectTone(originalMsg);
  if (tone === 'angry') {
    prefix = getCalmingPhrase() + " ";
  }
  if (awaitingAnswer && lastBotKey && keys[lastBotKey].replies) {
    const replies = keys[lastBotKey].replies;
    let bestReplyKey = null;
    let bestScore = Infinity;
    for (const replyKey in replies) {
      const distance = levenshteinDistance(userMessage, replyKey.toLowerCase());
      if (distance < bestScore && distance <= Math.max(1, Math.floor(replyKey.length / 2))) {
        bestScore = distance;
        bestReplyKey = replyKey;
      }
    }
  if (bestReplyKey) {
      pendingMessageKey = lastBotKey || null;
      awaitingAnswer = false;
      lastBotKey = null;
      return prefix + replies[bestReplyKey];
    } else {
      awaitingAnswer = false;
      lastBotKey = null;
      let key = await findClosestKey(userMessage, keys, synonymsDataset);
      if (key) {
        const options = keys[key].responses;
        const resp = options[Math.floor(Math.random() * options.length)];
        lastBotKey = key;
        pendingMessageKey = key;
        awaitingAnswer = true;
        return prefix + resp;
      }
  return prefix + getFallbackResponse();
    }
  }
  const parts = userMessage
    .split(/,|\.|;|\band\b/gi)
    .map(p => p.trim())
    .filter(Boolean);
  const responses = [];
  for (const part of parts) {
    const partType = detectType(part);
    if (partType === 'instruction') {
      responses.push(await handleInstructionSync(part));
      continue;
    }
    let key = await findClosestKey(part, keys, synonymsDataset, tone, partType === 'question' ? 'question' : null);
      console.log("Prompt type detected:", partType);
    if (!key) {
      if (partType === 'question') {
        try {
          if (hasMathQuestion(part)) {
            const mathAnswer = await solveMathFromString(part);
            if (mathAnswer) {
              lastBotKey = null;
              pendingMessageKey = null;
              awaitingAnswer = false;
              responses.push(mathAnswer);
              continue;
            }
          }
          const answer = await getAnswer(part);
          if (answer && typeof answer === 'string' && answer.trim().length > 0) {
            lastBotKey = null;
            pendingMessageKey = null;
            awaitingAnswer = false;
            responses.push(answer);
            continue;
          }
        } catch (err) {
          console.error('getAnswer failed:', err);
        }
      }
      responses.push(getFallbackResponse());
      continue;
    }
    const options = keys[key] && keys[key].responses && Array.isArray(keys[key].responses) ? keys[key].responses : (keys[key] && keys[key].responses ? [String(keys[key].responses)] : null);
    if (!options || options.length === 0) {
      responses.push(getFallbackResponse());
      continue;
    }
    const resp = options[Math.floor(Math.random() * options.length)];
    lastBotKey = key;
    pendingMessageKey = key;
    awaitingAnswer = true; 
    responses.push(resp);
  }
  return prefix + responses.join(" ");
}
const chatEl = document.getElementById('chat');
const inputEl = document.getElementById('input');
const sendBtn = document.getElementById('send');
let autoCompleteEl = document.getElementById('autocompleteContainer');
if (!autoCompleteEl) {
  autoCompleteEl = document.createElement('div');
  autoCompleteEl.id = 'autocompleteContainer';
  autoCompleteEl.style = 'max-width:900px;margin:6px auto 8px;padding:6px 12px;display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-start;position:relative;z-index:5;background:transparent;';
  const composer = document.querySelector('.composer');
  composer.insertBefore(autoCompleteEl, composer.firstChild);
}
function showAutocompleteSuggestions(prefix) {
  autoCompleteEl.innerHTML = '';
  if (!prefix || !keys || typeof keys !== 'object') return;
  const lower = prefix.toLowerCase().trim();
  const allKeys = Object.keys(keys || {}).filter(k => !isBlocked(k));
  const scored = allKeys.map(k => ({k, s: levenshteinDistance(lower, k.toLowerCase())})).sort((a,b)=>a.s-b.s).slice(0,5);
  for (const item of scored) {
    const btn = document.createElement('button');
  btn.className = 'btn autocomplete-btn';
  btn.style = 'padding:6px 10px;font-size:0.95rem;min-width:120px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;background:var(--elev);color:var(--text);border:1px solid var(--border);';
    btn.textContent = item.k;
    btn.onclick = () => {
      inputEl.value = item.k;
      inputEl.focus();
      autosize();
      autoCompleteEl.innerHTML = '';
    };
    autoCompleteEl.appendChild(btn);
  }
}
let botBusy = false;
const themeToggle = document.getElementById('themeToggle');
const convTitle = document.getElementById('convTitle');
const historyEl = document.getElementById('history');
let conversations = JSON.parse(localStorage.getItem('conversations_v1') || '[]');
let currentId = localStorage.getItem('current_conv_id');
if (!conversations.length || !currentId) {
  const conv = createConversation();
  currentId = conv.id;
  persist();
}
hydrate();
function createConversation(){
  const id = 'c_' + Math.random().toString(36).slice(2);
  const conv = { id, title:'New chat', messages:[] };
  conversations.unshift(conv);
  return conv;
}
function currentConv(){ return conversations.find(c => c.id===currentId) }
function persist(){
  localStorage.setItem('conversations_v1', JSON.stringify(conversations));
  localStorage.setItem('current_conv_id', currentId);
  checkStorageWarning();
}
function formatTime(ts){
  const d = new Date(ts);
  return d.toLocaleString([], {hour:'2-digit', minute:'2-digit'});
}
function el(tag, attrs={}, children=[]){
  const e = document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=>{
    if(k==='class') e.className=v;
    else if(k==='html') e.innerHTML=v;
    else e.setAttribute(k,v);
  });
  (Array.isArray(children)?children:[children]).filter(Boolean).forEach(ch=>{
    if(typeof ch==='string') e.appendChild(document.createTextNode(ch));
    else e.appendChild(ch);
  });
  return e;
}
function renderHistory() {
  historyEl.innerHTML = '';
  conversations.forEach(c => {
    const item = el('div', {
      class: 'conv' + (c.id === currentId ? ' active' : ''),
      role: 'button',
      tabindex: '0'
    });
    const left = el('div', {
      style: 'flex:1; display:flex; align-items:center; gap:10px;'
    });
    const avatarDiv = el('div', { class: 'avatar ' + (c.role === 'user' ? 'user' : 'bot') });
    if (c.role === 'user' && window.firebaseAuth && window.firebaseAuth.currentUser && window.firebaseAuth.currentUser.photoURL) {
      avatarDiv.innerHTML = `<img src="${window.firebaseAuth.currentUser.photoURL}" alt="avatar" style="width:100%; height:100%; border-radius:50%;">`;
    } else {
      if (c.role === 'user') {
        avatarDiv.innerHTML = '<i class="fas fa-user"></i>';
      } else {
  avatarDiv.innerHTML = '<img src="logo.png" alt="bot logo" style="width:100%; height:100%; border-radius:10px; background:none; object-fit:cover;">';
      }
    }
    left.append(
      avatarDiv,
      el('div', { class: 'title' }, c.title || 'Untitled')
    );
    const delBtn = el('button', { class: 'tool', title: 'Delete chat' }, '✕');
    delBtn.addEventListener('click', async e => {
      e.stopPropagation();
      const ok = await showConfirm('Delete this chat?');
      if (ok) {
        conversations = conversations.filter(x => x.id !== c.id);
        if (currentId === c.id) {
          const next = conversations[0] || createConversation();
          currentId = next.id;
        }
        persist();
        hydrate();
        checkStorageWarning();
      }
    });
    item.append(left, delBtn);
    item.addEventListener('click', () => {
      currentId = c.id;
      persist();
      hydrate();
    });
    historyEl.appendChild(item);
  });
}
function renderMessages(){
  chatEl.innerHTML='';
  const conv = currentConv();
  if (!conv.messages.length) {
    const container = el('div', { style: 'display:flex; flex-direction:column; align-items:center; margin-top:40px;' });
    const isLight = document.body.classList.contains('light');
    const emptyMsg = el('div', {
      class: 'empty-chat-message',
      style: `color:${isLight ? '#111' : '#fff'}; font-size:1.3em; text-align:center; font-weight:700; letter-spacing:0.01em;`
    }, 'Ask Me Anything!');
    const randomKeyDiv = el('div', { id: 'randomKeyMsg', style: 'margin-top:10px; color:var(--muted); font-size:1.08em; text-align:center; max-width:90vw; word-break:break-word;' });
    container.appendChild(emptyMsg);
    container.appendChild(randomKeyDiv);
    chatEl.appendChild(container);
    if (window._randomKeyInterval) clearInterval(window._randomKeyInterval);
    function setRandomKey() {
      if (typeof keys !== 'object' || !Object.keys(keys).length) {
        randomKeyDiv.textContent = '';
        return;
      }
      const keyList = Object.keys(keys);
      const randomKey = keyList[Math.floor(Math.random() * keyList.length)];
      randomKeyDiv.textContent = randomKey;
    }
    setRandomKey();
    window._randomKeyInterval = setInterval(setRandomKey, 1000);
    return;
  } else {
    if (window._randomKeyInterval) {
      clearInterval(window._randomKeyInterval);
      window._randomKeyInterval = null;
    }
  }
  conv.messages.forEach((m,i)=>{
    const row = el('div',{class:'msg '+m.role});
    const ava = el('div', { class: 'avatar ' + (m.role === 'user' ? 'user' : 'bot'), style: 'width:40px; height:40px; min-width:40px; min-height:40px; display:flex; align-items:center; justify-content:center;' });
    if (m.role === 'user' && auth.currentUser && auth.currentUser.photoURL) {
      ava.innerHTML = `<img src="${auth.currentUser.photoURL}" alt="avatar" style="width:100%; height:100%; border-radius:50%;">`;
    } else {
      if (m.role === 'user') {
        ava.innerHTML = '<i class="fas fa-user"></i>';
      } else {
  ava.innerHTML = '<img src="logo.png" alt="bot logo" style="width:100%; height:100%; border-radius:10px; object-fit:cover;">';
      }
    }
  const bubble = renderBubble(m.content);
    const tools = el('div',{class:'tools'});
    if(m.role==='assistant'){
      const copy = el('button',{class:'tool', title:'Copy message'}); copy.textContent='Copy';
      copy.addEventListener('click', ()=>navigator.clipboard.writeText(m.content));
      const reply = el('button',{class:'tool', title:'Reply to this message'}); reply.textContent='Reply';
      reply.addEventListener('click', ()=>replyAt(i));
      tools.append(copy, reply);
    }else{
      const edit = el('button',{class:'tool', title:'Edit & resend'}); edit.textContent='Edit';
      edit.addEventListener('click', ()=>{
        inputEl.value = m.content;
        inputEl.focus();
      });
      tools.append(edit);
    }
    const meta = el('div',{class:'timestamp'}, formatTime(m.ts));
    const col = el('div',{}, [bubble, tools, meta]);
    row.append(ava, col);
    if (m.role === 'user' && typeof m._replyTo === 'number') {
      const targetIdx = m._replyTo;
      const replyLink = el('div', {class: 'reply-link', title: 'Go to replied message', style: 'font-size:0.85rem;color:var(--muted);cursor:pointer;margin:0;'}, '↩︎ Reply');
      replyLink.addEventListener('click', ()=>scrollAndHighlight(targetIdx));
      const banner = el('div', {class: 'msg reply-banner', style: 'padding:2px 0 0 0; margin-bottom:4px;'}, []);
      const bannerAva = el('div', {class: 'avatar', style: 'width:36px; height:36px; background:transparent; border:0;'});
      const bannerCol = el('div', {style: 'display:flex; align-items:center; padding-left:8px;'}, [replyLink]);
      banner.append(bannerAva, bannerCol);
      chatEl.appendChild(banner);
    }
    chatEl.appendChild(row);
  });
  chatEl.scrollTop = chatEl.scrollHeight;
}
function renderMarkdown(text){
  const host = el('div');
  const fenced = /^```(\w+)?\n([\s\S]*?)```/gm;
  let lastIndex = 0, match;
  while((match = fenced.exec(text))!==null){
    if(match.index > lastIndex) host.appendChild(p(text.slice(lastIndex, match.index)));
    host.appendChild(codeblock(match[2]));
    lastIndex = fenced.lastIndex;
  }
  if(lastIndex < text.length) host.appendChild(p(text.slice(lastIndex)));
  return host;
  function p(t){
    const pp = el('p');
    t = t.replace(/`([^`]+)`/g, (_,c)=>'§CODE§'+c+'§/CODE§');
    t = t.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>')
         .replace(/\*([^*]+)\*/g,'<em>$1</em>');
    const imgRegex = /!\[([^\]]*)\]\(([^)]+)\)/g;
    let lastPos = 0;
    let matchImg;
    while((matchImg = imgRegex.exec(t))!==null){
      if(matchImg.index > lastPos) {
        const part = t.slice(lastPos, matchImg.index);
        insertTextOrCode(pp, part);
      }
      const imgEl = el('img', {src: matchImg[2], alt: matchImg[1], style:'max-width:100%; border-radius:12px; margin-top:6px; display:block;'});
      pp.appendChild(imgEl);
      lastPos = matchImg.index + matchImg[0].length;
    }
    if(lastPos < t.length){
      const part = t.slice(lastPos);
      insertTextOrCode(pp, part);
    }
    return pp;
  }
  function insertTextOrCode(pp, t){
    const parts = t.split(/§CODE§|§\/CODE§/);
    for(let i=0;i<parts.length;i++){
      if(i%2===1){ const code = el('code',{},parts[i]); pp.appendChild(code); }
      else pp.insertAdjacentHTML('beforeend', parts[i]);
    }
  }
  function codeblock(code){
    const pre = el('pre'); 
    const codeEl = el('code',{},code);
    pre.appendChild(codeEl);
    const cp = el('div',{class:'copy'},['Copy code']);
    cp.addEventListener('click', ()=>{
      navigator.clipboard.writeText(code);
      cp.textContent='Copied';
      setTimeout(()=>cp.textContent='Copy code',800);
    });
    const wrap = el('div'); wrap.append(pre, cp); return wrap;
  }
}
function setTitleFromFirstUser(){
  const conv = currentConv();
  const firstUser = conv.messages.find(m=>m.role==='user');
  conv.title = firstUser ? (firstUser.content.slice(0,30) + (firstUser.content.length>30?'…':'')) : 'New chat';
}
async function sendMessage(text){
  const PRIV_KEY = 'privacy_agreed_v1';
  const agreed = localStorage.getItem(PRIV_KEY) === 'true';
  const trimmed = (text || '').trim();
  if (!agreed) {
    const lower = trimmed.toLowerCase();
    const conv = currentConv();
    if (lower === 'yes') {
      localStorage.setItem(PRIV_KEY, 'true');
      const okMsg = { role: 'assistant', content: 'Thanks — you have agreed to the privacy policy. You can continue chatting now.', ts: Date.now() };
      conv.messages.push(okMsg);
      persist(); renderMessages();
      inputEl.value = '';
      autosize();
      return;
    }
  const prompt = 'By continuing to chat you agree to our <a href="privacy.html" target="_blank" rel="noopener" style="color:#1e90ff;text-decoration:underline;">privacy policy</a>, if you agree type yes';
    const botMsg = { role: 'assistant', content: prompt, ts: Date.now() };
    conv.messages.push(botMsg);
    persist(); renderMessages();
    inputEl.value = '';
    autosize();
    return;
  }
  botBusy = true;
  sendBtn.disabled = true;
  inputEl.disabled = true;
  const conv = currentConv();
  const userMsg = {role:'user', content:trimmed, ts:Date.now()};
  if (typeof replyTargetIndex === 'number') {
    userMsg._replyTo = replyTargetIndex;
    replyTargetIndex = null;
  }
  conv.messages.push(userMsg);
  if(conv.messages.length===1) setTitleFromFirstUser();
  persist(); renderMessages();
  inputEl.value=''; autosize();
  if (webSearchMode) {
    const typingRow = el('div',{class:'msg assistant'});
    typingRow.append(
      el('div', {class: 'avatar bot', html: '<img src="logo.png" alt="bot logo" style="width:100%; height:100%; border-radius:10px; object-fit:cover;">'}),
      el('div',{class:'bubble'}, el('span',{class:'typing'},[
        el('span',{class:'dot'}), el('span',{class:'dot'}), el('span',{class:'dot'})
      ]))
    );
    chatEl.appendChild(typingRow);
    chatEl.scrollTop = chatEl.scrollHeight;
    try {
      const answer = await getAnswer(trimmed);
      typingRow.remove();
      const botMsg = {role:'assistant', content: answer || 'No results found.', ts: Date.now(), _key: null};
      conv.messages.push(botMsg);
      pendingMessageKey = null;
      persist();
      await streamMessage(botMsg);
    } catch (e) {
      typingRow.remove();
      const botMsg = {role:'assistant', content: 'Web search failed.', ts: Date.now(), _key: null};
      conv.messages.push(botMsg); persist(); renderMessages();
    }
    botBusy = false; sendBtn.disabled = false; inputEl.disabled = false;
    return;
  }
  if(imageMode){
    const typingRow = el('div',{class:'msg assistant'});
    const bubble = el('div',{class:'bubble'});
  bubble.innerHTML = '';
    let botMsg;
    if(imgUrl){
      const imgEl = el('img', {src: imgUrl, alt: text, style:'max-width:100%; border-radius:12px; display:block;'});
      bubble.appendChild(el('p', {}, `Here's an image for "${text}":`));
      bubble.appendChild(imgEl);
  botMsg = {role:'assistant', content:`Image: ${imgUrl}`, ts: Date.now(), _key: pendingMessageKey || null};
    } else {
      bubble.appendChild(el('p', {}, `Sorry, I couldn't find an image for "${text}".`));
  botMsg = {role:'assistant', content:`No image found for "${text}"`, ts: Date.now(), _key: pendingMessageKey || null};
    }
    conv.messages.push(botMsg);
    persist();
    chatEl.scrollTop = chatEl.scrollHeight;
    imageMode = false;
    document.getElementById('imageToggle').classList.remove('primary');
  botBusy = false;
  sendBtn.disabled = false;
  inputEl.disabled = false;
  return;
  }
  if(jsFixMode){
    const typingRow = el('div',{class:'msg assistant'});
    typingRow.append(
  el('div', {class: 'avatar bot', style: 'width:40px; height:40px; min-width:40px; min-height:40px; display:flex; align-items:center; justify-content:center;', html: '<img src="logo.png" alt="bot logo" style="width:100%; height:100%; border-radius:10px; object-fit:cover;">'}),
      el('div',{class:'bubble'}, el('span',{class:'typing'},[
        el('span',{class:'dot'}), el('span',{class:'dot'}), el('span',{class:'dot'})
      ]))
    );
    chatEl.appendChild(typingRow);
    chatEl.scrollTop = chatEl.scrollHeight;
    await new Promise(r=>setTimeout(r, 350 + Math.random()*200));
  const fixedReport = await autoRunAndFix(text, 5, 2000);
    typingRow.remove();
  const botMsg = {role:'assistant', content:fixedReport, ts:Date.now(), _key: pendingMessageKey || null};
    conv.messages.push(botMsg);
    persist();
    await streamMessage(botMsg);
  botBusy = false;
  sendBtn.disabled = false;
  inputEl.disabled = false;
  return;
  }
  const typingRow = el('div',{class:'msg assistant'});
  typingRow.append(
  el('div', {class: 'avatar bot', html: '<img src="logo.png" alt="bot logo" style="width:100%; height:100%; border-radius:10px; object-fit:cover;">'}),
    el('div',{class:'bubble'}, el('span',{class:'typing'},[
      el('span',{class:'dot'}), el('span',{class:'dot'}), el('span',{class:'dot'})
    ]))
  );
  chatEl.appendChild(typingRow);
  chatEl.scrollTop = chatEl.scrollHeight;
  await new Promise(r=>setTimeout(r, 350 + Math.random()*200));
  const botText = await generateBotMessage(text);
  typingRow.remove();
  const botMsg = {role:'assistant', content:botText, ts:Date.now(), _key: pendingMessageKey || null};
  conv.messages.push(botMsg);
  pendingMessageKey = null;
  persist();
  await streamMessage(botMsg);
  botBusy = false;
  sendBtn.disabled = false;
  inputEl.disabled = false;
}
async function streamMessage(msg){
  const row = el('div',{class:'msg assistant'});
  const avatarDiv = el('div', {class: 'avatar bot', style: 'width:40px; height:40px; min-width:40px; min-height:40px; display:flex; align-items:center; justify-content:center;', html: '<img src="logo.png" alt="bot logo" style="width:100%; height:100%; border-radius:10px; object-fit:cover;">'});
  const col = el('div', {}, [ el('div',{class:'bubble', id:'streamBubble'}) ]);
  row.append(avatarDiv, col);
  chatEl.appendChild(row);
  chatEl.scrollTop = chatEl.scrollHeight;
  const bubble = col.querySelector('#streamBubble');
  const chars = msg.content.split('');
  let buffer='';
  for(let i=0;i<chars.length;i++){
    buffer += chars[i];
    bubble.textContent = buffer;
    if(i%3===0) await new Promise(r=>setTimeout(r, 12));
  }
  bubble.replaceWith(renderBubble(buffer));
  const meta = el('div',{class:'timestamp'}, formatTime(msg.ts));
  const tools = el('div',{class:'tools'});
  const copy = el('button',{class:'tool'}); copy.textContent='Copy';
  copy.addEventListener('click', ()=>navigator.clipboard.writeText(msg.content));
  const reply = el('button',{class:'tool'}); reply.textContent='Reply';
  reply.addEventListener('click', ()=>replyAt(currentConv().messages.indexOf(msg)));
  tools.append(copy, reply);
  col.append(tools, meta);
  chatEl.scrollTop = chatEl.scrollHeight;
}
function regenerateAt(index){
  const conv = currentConv();
  const userBefore = conv.messages.slice(0, index).reverse().find(m=>m.role==='user');
  if(!userBefore) return;
  conv.messages = conv.messages.slice(0, index);
  persist(); renderMessages();
  sendMessage(userBefore.content);
}
function replyAt(index){
  const conv = currentConv();
  const msg = conv.messages[index];
  if(!msg) return;
  if(msg._key) lastBotKey = msg._key;
  awaitingAnswer = true;
  replyTargetIndex = index;
  inputEl.focus();
  inputEl.placeholder = 'Replying to the bot...';
}
sendBtn.addEventListener('click', trySend);
inputEl.addEventListener('keydown', (e)=>{
  if(e.key==='Enter' && !e.shiftKey){
    e.preventDefault(); trySend();
  }
});
function trySend(){
  if(botBusy) return;
  const text = inputEl.value.trim();
  if(!text) return;
  inputEl.placeholder = 'Say anything...';
  sendMessage(text);
}
function autosize(){
  inputEl.style.height='auto';
  inputEl.style.height=Math.min(inputEl.scrollHeight, 400)+'px';
}
inputEl.addEventListener('input', autosize);
window.addEventListener('resize', autosize);
document.addEventListener('keydown', (e) => {
  try {
    if (e.ctrlKey) return;
    if (document.activeElement === inputEl) return;
    const tgt = e.target;
    if (tgt && (tgt.tagName === 'INPUT' || tgt.tagName === 'TEXTAREA' || tgt.isContentEditable)) return;
    if (e.key && e.key.length === 1) {
      e.preventDefault();
      inputEl.focus();
      inputEl.value = inputEl.value + e.key;
      autosize();
      inputEl.selectionStart = inputEl.selectionEnd = inputEl.value.length;
    }
  } catch (err) {
  }
});
inputEl.addEventListener('input', (e) => {
  const v = inputEl.value;
  showAutocompleteSuggestions(v);
});
inputEl.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    autoCompleteEl.innerHTML = '';
    return;
  }
  if (e.key === 'ArrowDown') {
    const first = autoCompleteEl.querySelector('button');
    if (first) { first.focus(); e.preventDefault(); }
  }
});
document.addEventListener('click', (e) => {
  if (!autoCompleteEl.contains(e.target) && e.target !== inputEl) autoCompleteEl.innerHTML = '';
});
document.getElementById('newChat').addEventListener('click', ()=>{
  const conv = createConversation();
  currentId = conv.id; persist(); hydrate();
});
document.getElementById('clearAll').addEventListener('click', async ()=>{
  const ok = await showConfirm('Clear all conversations?');
  if(!ok) return;
  conversations=[]; currentId=createConversation().id; persist(); hydrate();
});
document.getElementById('exportBtn').addEventListener('click', ()=>{
  const blob = new Blob([JSON.stringify({version:1, conversations}, null, 2)], {type:'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'Jumbo-local-export.json';
  a.click();
});
document.getElementById('importBtn').addEventListener('click', ()=>{
  const inp = document.createElement('input'); inp.type='file'; inp.accept='application/json';
  inp.onchange = e=>{
    const file = e.target.files[0]; if(!file) return;
    file.text().then(t=>{
      try{
        const data = JSON.parse(t);
        if(Array.isArray(data.conversations)) conversations = data.conversations;
        else if(Array.isArray(data)) conversations = data;
        currentId = conversations[0]?.id || createConversation().id;
        persist(); hydrate();
  }catch(err){ showPopup('Invalid file', {buttonText:'Close'}); }
    });
  };
  inp.click();
});
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('light');
  if(document.body.classList.contains('light')){
    localStorage.setItem('theme', 'light');
  } else {
    localStorage.setItem('theme', 'dark');
  }
  renderMessages();
});
const savedTheme = localStorage.getItem('theme');
if(savedTheme === 'light'){
  document.body.classList.add('light');
}
function hydrate(){
  renderHistory();
  convTitle.textContent = currentConv()?.title || 'New chat';
  renderMessages();
}
const webBtn = document.getElementById('webSearch');
if (webBtn) {
  webBtn.addEventListener('click', () => { setActiveTool(webSearchMode ? null : 'web'); });
}
function scrollAndHighlight(index){
  const conv = currentConv();
  const rows = Array.from(chatEl.querySelectorAll('.msg'));
  if(index < 0 || index >= conv.messages.length) return;
  const row = rows[index];
  if(!row) return;
  row.scrollIntoView({behavior:'smooth', block:'center'});
  const bubble = row.querySelector('.bubble');
  if(!bubble) return;
  const origBg = bubble.style.background;
  bubble.style.transition = 'background-color 0.25s ease';
  bubble.style.background = 'rgba(16,163,127,0.08)';
  setTimeout(()=>{ bubble.style.background = origBg || ''; }, 900);
}