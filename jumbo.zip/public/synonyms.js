const synonymsDataset = {
  "hi": [
    "hi",
    "hello",
    "hiya",
    "yo",
    "howdy"
  ],
  "hello": [
    "hi",
    "hello",
    "hiya",
    "yo",
    "howdy"
  ],
  "hey": [
    "hi",
    "hello",
    "hiya",
    "yo",
    "howdy"
  ],
  "hiya": [
    "hi",
    "hello",
    "hiya",
    "yo",
    "howdy"
  ],
  "howdy": [
    "hi",
    "hello",
    "hiya",
    "yo",
    "howdy"
  ],
  "greetings": [
    "hi",
    "hey",
    "hiya",
    "greetings",
    "salutations"
  ],
  "salutations": [
    "hi",
    "hey",
    "hiya",
    "greetings",
    "salutations"
  ],
  "yo": [
    "hi",
    "hello",
    "hiya",
    "yo",
    "howdy"
  ],
  "I": [
    "me",
    "myself"
  ],
  "me": [
    "me",
    "myself"
  ],
  "myself": [
    "me",
    "myself"
  ],
  "you": [
    "u",
    "yourself"
  ],
  "u": [
    "u",
    "yourself"
  ],
  "yourself": [
    "u",
    "yourself"
  ],
  "we": [
    "us",
    "ourselves"
  ],
  "us": [
    "us",
    "ourselves"
  ],
  "ourselves": [
    "us",
    "ourselves"
  ],
  "they": [
    "them",
    "themselves"
  ],
  "them": [
    "them",
    "themselves"
  ],
  "themselves": [
    "them",
    "themselves"
  ],
  "go": [
    "move",
    "travel",
    "walk",
    "proceed",
    "head"
  ],
  "move": [
    "move",
    "travel",
    "walk",
    "proceed",
    "head"
  ],
  "travel": [
    "move",
    "travel",
    "walk",
    "proceed",
    "head"
  ],
  "walk": [
    "stroll",
    "saunter",
    "amble",
    "march",
    "wander"
  ],
  "proceed": [
    "move",
    "travel",
    "walk",
    "proceed",
    "head"
  ],
  "head": [
    "move",
    "travel",
    "walk",
    "proceed",
    "head"
  ],
  "come": [
    "arrive",
    "approach",
    "reach",
    "get",
    "enter"
  ],
  "arrive": [
    "arrive",
    "approach",
    "reach",
    "get",
    "enter"
  ],
  "approach": [
    "arrive",
    "approach",
    "reach",
    "get",
    "enter"
  ],
  "reach": [
    "arrive",
    "approach",
    "reach",
    "get",
    "enter"
  ],
  "get": [
    "obtain",
    "receive",
    "acquire",
    "gain",
    "fetch"
  ],
  "enter": [
    "arrive",
    "approach",
    "reach",
    "get",
    "enter"
  ],
  "do": [
    "perform",
    "carry out",
    "execute",
    "act",
    "accomplish"
  ],
  "perform": [
    "perform",
    "carry out",
    "execute",
    "act",
    "accomplish"
  ],
  "carry out": [
    "perform",
    "carry out",
    "execute",
    "act",
    "accomplish"
  ],
  "execute": [
    "perform",
    "carry out",
    "execute",
    "act",
    "accomplish"
  ],
  "act": [
    "perform",
    "carry out",
    "execute",
    "act",
    "accomplish"
  ],
  "accomplish": [
    "perform",
    "carry out",
    "execute",
    "act",
    "accomplish"
  ],
  "make": [
    "create",
    "build",
    "produce",
    "construct",
    "form"
  ],
  "create": [
    "create",
    "build",
    "produce",
    "construct",
    "form"
  ],
  "build": [
    "create",
    "build",
    "produce",
    "construct",
    "form"
  ],
  "produce": [
    "create",
    "build",
    "produce",
    "construct",
    "form"
  ],
  "construct": [
    "create",
    "build",
    "produce",
    "construct",
    "form"
  ],
  "form": [
    "create",
    "build",
    "produce",
    "construct",
    "form"
  ],
  "say": [
    "speak",
    "tell",
    "utter",
    "express",
    "state"
  ],
  "speak": [
    "speak",
    "tell",
    "utter",
    "express",
    "state"
  ],
  "tell": [
    "speak",
    "tell",
    "utter",
    "express",
    "state"
  ],
  "utter": [
    "speak",
    "tell",
    "utter",
    "express",
    "state"
  ],
  "express": [
    "speak",
    "tell",
    "utter",
    "express",
    "state"
  ],
  "state": [
    "speak",
    "tell",
    "utter",
    "express",
    "state"
  ],
  "obtain": [
    "obtain",
    "receive",
    "acquire",
    "gain",
    "fetch"
  ],
  "receive": [
    "obtain",
    "receive",
    "acquire",
    "gain",
    "fetch"
  ],
  "acquire": [
    "obtain",
    "receive",
    "acquire",
    "gain",
    "fetch"
  ],
  "gain": [
    "obtain",
    "receive",
    "acquire",
    "gain",
    "fetch"
  ],
  "fetch": [
    "obtain",
    "receive",
    "acquire",
    "gain",
    "fetch"
  ],
  "take": [
    "grab",
    "hold",
    "pick",
    "seize",
    "collect"
  ],
  "grab": [
    "grab",
    "hold",
    "pick",
    "seize",
    "collect"
  ],
  "hold": [
    "possess",
    "own",
    "contain",
    "hold",
    "include"
  ],
  "pick": [
    "grab",
    "hold",
    "pick",
    "seize",
    "collect"
  ],
  "seize": [
    "grab",
    "hold",
    "pick",
    "seize",
    "collect"
  ],
  "collect": [
    "grab",
    "hold",
    "pick",
    "seize",
    "collect"
  ],
  "see": [
    "look",
    "view",
    "watch",
    "observe",
    "notice"
  ],
  "look": [
    "look",
    "view",
    "watch",
    "observe",
    "notice"
  ],
  "view": [
    "look",
    "view",
    "watch",
    "observe",
    "notice"
  ],
  "watch": [
    "look",
    "view",
    "watch",
    "observe",
    "notice"
  ],
  "observe": [
    "look",
    "view",
    "watch",
    "observe",
    "notice"
  ],
  "notice": [
    "look",
    "view",
    "watch",
    "observe",
    "notice"
  ],
  "know": [
    "understand",
    "recognize",
    "realize",
    "learn",
    "perceive"
  ],
  "understand": [
    "understand",
    "recognize",
    "realize",
    "learn",
    "perceive"
  ],
  "recognize": [
    "understand",
    "recognize",
    "realize",
    "learn",
    "perceive"
  ],
  "realize": [
    "understand",
    "recognize",
    "realize",
    "learn",
    "perceive"
  ],
  "learn": [
    "understand",
    "recognize",
    "realize",
    "learn",
    "perceive"
  ],
  "perceive": [
    "understand",
    "recognize",
    "realize",
    "learn",
    "perceive"
  ],
  "think": [
    "consider",
    "ponder",
    "reflect",
    "believe",
    "reason"
  ],
  "consider": [
    "consider",
    "ponder",
    "reflect",
    "believe",
    "reason"
  ],
  "ponder": [
    "consider",
    "ponder",
    "reflect",
    "believe",
    "reason"
  ],
  "reflect": [
    "consider",
    "ponder",
    "reflect",
    "believe",
    "reason"
  ],
  "believe": [
    "consider",
    "ponder",
    "reflect",
    "believe",
    "reason"
  ],
  "reason": [
    "consider",
    "ponder",
    "reflect",
    "believe",
    "reason"
  ],
  "good": [
    "nice",
    "great",
    "fine",
    "pleasant",
    "excellent"
  ],
  "nice": [
    "nice",
    "great",
    "fine",
    "pleasant",
    "excellent"
  ],
  "great": [
    "nice",
    "great",
    "fine",
    "pleasant",
    "excellent"
  ],
  "fine": [
    "nice",
    "great",
    "fine",
    "pleasant",
    "excellent"
  ],
  "pleasant": [
    "nice",
    "great",
    "fine",
    "pleasant",
    "excellent"
  ],
  "excellent": [
    "nice",
    "great",
    "fine",
    "pleasant",
    "excellent"
  ],
  "bad": [
    "poor",
    "wrong",
    "awful",
    "terrible",
    "unpleasant"
  ],
  "poor": [
    "poor",
    "wrong",
    "awful",
    "terrible",
    "unpleasant"
  ],
  "wrong": [
    "poor",
    "wrong",
    "awful",
    "terrible",
    "unpleasant"
  ],
  "awful": [
    "poor",
    "wrong",
    "awful",
    "terrible",
    "unpleasant"
  ],
  "terrible": [
    "poor",
    "wrong",
    "awful",
    "terrible",
    "unpleasant"
  ],
  "unpleasant": [
    "poor",
    "wrong",
    "awful",
    "terrible",
    "unpleasant"
  ],
  "big": [
    "large",
    "huge",
    "enormous",
    "giant",
    "massive"
  ],
  "large": [
    "large",
    "huge",
    "enormous",
    "giant",
    "massive"
  ],
  "huge": [
    "large",
    "huge",
    "enormous",
    "giant",
    "massive"
  ],
  "enormous": [
    "large",
    "huge",
    "enormous",
    "giant",
    "massive"
  ],
  "giant": [
    "large",
    "huge",
    "enormous",
    "giant",
    "massive"
  ],
  "massive": [
    "large",
    "huge",
    "enormous",
    "giant",
    "massive"
  ],
  "small": [
    "tiny",
    "little",
    "mini",
    "petite",
    "minor"
  ],
  "tiny": [
    "tiny",
    "little",
    "mini",
    "petite",
    "minor"
  ],
  "little": [
    "tiny",
    "little",
    "mini",
    "petite",
    "minor"
  ],
  "mini": [
    "tiny",
    "little",
    "mini",
    "petite",
    "minor"
  ],
  "petite": [
    "tiny",
    "little",
    "mini",
    "petite",
    "minor"
  ],
  "minor": [
    "tiny",
    "little",
    "mini",
    "petite",
    "minor"
  ],
  "friend": [
    "buddy",
    "pal",
    "mate",
    "companion",
    "chum"
  ],
  "buddy": [
    "buddy",
    "pal",
    "mate",
    "companion",
    "chum"
  ],
  "pal": [
    "buddy",
    "pal",
    "mate",
    "companion",
    "chum"
  ],
  "mate": [
    "sib",
    "sis",
    "sibling",
    "mate",
    "kin"
  ],
  "companion": [
    "buddy",
    "pal",
    "mate",
    "companion",
    "chum"
  ],
  "chum": [
    "buddy",
    "pal",
    "mate",
    "companion",
    "chum"
  ],
  "day": [
    "time",
    "period",
    "date",
    "24 hours",
    "daytime"
  ],
  "time": [
    "time",
    "period",
    "date",
    "24 hours",
    "daytime"
  ],
  "period": [
    "time",
    "period",
    "date",
    "24 hours",
    "daytime"
  ],
  "date": [
    "time",
    "period",
    "date",
    "24 hours",
    "daytime"
  ],
  "24 hours": [
    "time",
    "period",
    "date",
    "24 hours",
    "daytime"
  ],
  "daytime": [
    "time",
    "period",
    "date",
    "24 hours",
    "daytime"
  ],
  "night": [
    "evening",
    "dark",
    "nighttime",
    "late hours",
    "midnight"
  ],
  "evening": [
    "evening",
    "dark",
    "nighttime",
    "late hours",
    "midnight"
  ],
  "dark": [
    "ebony",
    "jet",
    "charcoal",
    "onyx",
    "dark"
  ],
  "nighttime": [
    "evening",
    "dark",
    "nighttime",
    "late hours",
    "midnight"
  ],
  "late hours": [
    "evening",
    "dark",
    "nighttime",
    "late hours",
    "midnight"
  ],
  "midnight": [
    "evening",
    "dark",
    "nighttime",
    "late hours",
    "midnight"
  ],
  "house": [
    "house",
    "residence",
    "dwelling",
    "abode",
    "place"
  ],
  "home": [
    "house",
    "residence",
    "dwelling",
    "abode",
    "place"
  ],
  "residence": [
    "house",
    "residence",
    "dwelling",
    "abode",
    "place"
  ],
  "dwelling": [
    "house",
    "residence",
    "dwelling",
    "abode",
    "place"
  ],
  "abode": [
    "house",
    "residence",
    "dwelling",
    "abode",
    "place"
  ],
  "place": [
    "house",
    "residence",
    "dwelling",
    "abode",
    "place"
  ],
  "hot": [
    "warm",
    "scorching",
    "boiling",
    "sweltering",
    "heated"
  ],
  "warm": [
    "warm",
    "scorching",
    "boiling",
    "sweltering",
    "heated"
  ],
  "scorching": [
    "warm",
    "scorching",
    "boiling",
    "sweltering",
    "heated"
  ],
  "boiling": [
    "warm",
    "scorching",
    "boiling",
    "sweltering",
    "heated"
  ],
  "sweltering": [
    "warm",
    "scorching",
    "boiling",
    "sweltering",
    "heated"
  ],
  "heated": [
    "warm",
    "scorching",
    "boiling",
    "sweltering",
    "heated"
  ],
  "cold": [
    "chilly",
    "freezing",
    "frigid",
    "icy",
    "cool"
  ],
  "chilly": [
    "chilly",
    "freezing",
    "frigid",
    "icy",
    "cool"
  ],
  "freezing": [
    "chilly",
    "freezing",
    "frigid",
    "icy",
    "cool"
  ],
  "frigid": [
    "chilly",
    "freezing",
    "frigid",
    "icy",
    "cool"
  ],
  "icy": [
    "chilly",
    "freezing",
    "frigid",
    "icy",
    "cool"
  ],
  "cool": [
    "chilly",
    "freezing",
    "frigid",
    "icy",
    "cool"
  ],
  "new": [
    "fresh",
    "recent",
    "novel",
    "modern",
    "current"
  ],
  "fresh": [
    "fresh",
    "recent",
    "novel",
    "modern",
    "current"
  ],
  "recent": [
    "fresh",
    "recent",
    "novel",
    "modern",
    "current"
  ],
  "novel": [
    "fresh",
    "recent",
    "novel",
    "modern",
    "current"
  ],
  "modern": [
    "fresh",
    "recent",
    "novel",
    "modern",
    "current"
  ],
  "current": [
    "fresh",
    "recent",
    "novel",
    "modern",
    "current"
  ],
  "old": [
    "ancient",
    "aged",
    "elderly",
    "antique",
    "vintage"
  ],
  "ancient": [
    "ancient",
    "aged",
    "elderly",
    "antique",
    "vintage"
  ],
  "aged": [
    "ancient",
    "aged",
    "elderly",
    "antique",
    "vintage"
  ],
  "elderly": [
    "ancient",
    "aged",
    "elderly",
    "antique",
    "vintage"
  ],
  "antique": [
    "ancient",
    "aged",
    "elderly",
    "antique",
    "vintage"
  ],
  "vintage": [
    "ancient",
    "aged",
    "elderly",
    "antique",
    "vintage"
  ],
  "fast": [
    "quick",
    "rapid",
    "speedy",
    "swift",
    "fleet"
  ],
  "quick": [
    "quick",
    "rapid",
    "speedy",
    "swift",
    "fleet"
  ],
  "rapid": [
    "quick",
    "rapid",
    "speedy",
    "swift",
    "fleet"
  ],
  "speedy": [
    "quick",
    "rapid",
    "speedy",
    "swift",
    "fleet"
  ],
  "swift": [
    "quick",
    "rapid",
    "speedy",
    "swift",
    "fleet"
  ],
  "fleet": [
    "quick",
    "rapid",
    "speedy",
    "swift",
    "fleet"
  ],
  "slow": [
    "sluggish",
    "lethargic",
    "unhurried",
    "delayed",
    "lagging"
  ],
  "sluggish": [
    "sluggish",
    "lethargic",
    "unhurried",
    "delayed",
    "lagging"
  ],
  "lethargic": [
    "sluggish",
    "lethargic",
    "unhurried",
    "delayed",
    "lagging"
  ],
  "unhurried": [
    "sluggish",
    "lethargic",
    "unhurried",
    "delayed",
    "lagging"
  ],
  "delayed": [
    "sluggish",
    "lethargic",
    "unhurried",
    "delayed",
    "lagging"
  ],
  "lagging": [
    "sluggish",
    "lethargic",
    "unhurried",
    "delayed",
    "lagging"
  ],
  "light": [
    "bright",
    "illuminated",
    "radiant",
    "glowing",
    "luminous"
  ],
  "bright": [
    "bright",
    "illuminated",
    "radiant",
    "glowing",
    "luminous"
  ],
  "illuminated": [
    "bright",
    "illuminated",
    "radiant",
    "glowing",
    "luminous"
  ],
  "radiant": [
    "bright",
    "illuminated",
    "radiant",
    "glowing",
    "luminous"
  ],
  "glowing": [
    "bright",
    "illuminated",
    "radiant",
    "glowing",
    "luminous"
  ],
  "luminous": [
    "bright",
    "illuminated",
    "radiant",
    "glowing",
    "luminous"
  ],
  "dim": [
    "dim",
    "shadowy",
    "gloomy",
    "murky",
    "black"
  ],
  "shadowy": [
    "dim",
    "shadowy",
    "gloomy",
    "murky",
    "black"
  ],
  "gloomy": [
    "unhappy",
    "sorrowful",
    "downcast",
    "miserable",
    "gloomy"
  ],
  "murky": [
    "dim",
    "shadowy",
    "gloomy",
    "murky",
    "black"
  ],
  "black": [
    "ebony",
    "jet",
    "charcoal",
    "onyx",
    "dark"
  ],
  "happy": [
    "joyful",
    "cheerful",
    "content",
    "delighted",
    "pleased"
  ],
  "joyful": [
    "joyful",
    "cheerful",
    "content",
    "delighted",
    "pleased"
  ],
  "cheerful": [
    "joyful",
    "cheerful",
    "content",
    "delighted",
    "pleased"
  ],
  "content": [
    "joyful",
    "cheerful",
    "content",
    "delighted",
    "pleased"
  ],
  "delighted": [
    "joyful",
    "cheerful",
    "content",
    "delighted",
    "pleased"
  ],
  "pleased": [
    "joyful",
    "cheerful",
    "content",
    "delighted",
    "pleased"
  ],
  "sad": [
    "unhappy",
    "sorrowful",
    "downcast",
    "miserable",
    "gloomy"
  ],
  "unhappy": [
    "unhappy",
    "sorrowful",
    "downcast",
    "miserable",
    "gloomy"
  ],
  "sorrowful": [
    "unhappy",
    "sorrowful",
    "downcast",
    "miserable",
    "gloomy"
  ],
  "downcast": [
    "unhappy",
    "sorrowful",
    "downcast",
    "miserable",
    "gloomy"
  ],
  "miserable": [
    "unhappy",
    "sorrowful",
    "downcast",
    "miserable",
    "gloomy"
  ],
  "yes": [
    "yeah",
    "yep",
    "sure",
    "affirmative",
    "indeed"
  ],
  "yeah": [
    "yeah",
    "yep",
    "sure",
    "affirmative",
    "indeed"
  ],
  "yep": [
    "yeah",
    "yep",
    "sure",
    "affirmative",
    "indeed"
  ],
  "sure": [
    "yeah",
    "yep",
    "sure",
    "affirmative",
    "indeed"
  ],
  "affirmative": [
    "yeah",
    "yep",
    "sure",
    "affirmative",
    "indeed"
  ],
  "indeed": [
    "yeah",
    "yep",
    "sure",
    "affirmative",
    "indeed"
  ],
  "no": [
    "nah",
    "nope",
    "not",
    "never",
    "negative"
  ],
  "nah": [
    "nah",
    "nope",
    "not",
    "never",
    "negative"
  ],
  "nope": [
    "nah",
    "nope",
    "not",
    "never",
    "negative"
  ],
  "not": [
    "nah",
    "nope",
    "not",
    "never",
    "negative"
  ],
  "never": [
    "nah",
    "nope",
    "not",
    "never",
    "negative"
  ],
  "negative": [
    "nah",
    "nope",
    "not",
    "never",
    "negative"
  ],
  "up": [
    "above",
    "higher",
    "overhead",
    "aloft",
    "skyward"
  ],
  "above": [
    "upon",
    "above",
    "over",
    "atop",
    "regarding"
  ],
  "higher": [
    "above",
    "higher",
    "overhead",
    "aloft",
    "skyward"
  ],
  "overhead": [
    "above",
    "higher",
    "overhead",
    "aloft",
    "skyward"
  ],
  "aloft": [
    "above",
    "higher",
    "overhead",
    "aloft",
    "skyward"
  ],
  "skyward": [
    "above",
    "higher",
    "overhead",
    "aloft",
    "skyward"
  ],
  "down": [
    "below",
    "under",
    "beneath",
    "lower",
    "groundward"
  ],
  "below": [
    "below",
    "under",
    "beneath",
    "lower",
    "groundward"
  ],
  "under": [
    "below",
    "under",
    "beneath",
    "lower",
    "groundward"
  ],
  "beneath": [
    "below",
    "under",
    "beneath",
    "lower",
    "groundward"
  ],
  "lower": [
    "below",
    "under",
    "beneath",
    "lower",
    "groundward"
  ],
  "groundward": [
    "below",
    "under",
    "beneath",
    "lower",
    "groundward"
  ],
  "red": [
    "crimson",
    "scarlet",
    "ruby",
    "cherry",
    "vermilion"
  ],
  "crimson": [
    "crimson",
    "scarlet",
    "ruby",
    "cherry",
    "vermilion"
  ],
  "scarlet": [
    "crimson",
    "scarlet",
    "ruby",
    "cherry",
    "vermilion"
  ],
  "ruby": [
    "crimson",
    "scarlet",
    "ruby",
    "cherry",
    "vermilion"
  ],
  "cherry": [
    "crimson",
    "scarlet",
    "ruby",
    "cherry",
    "vermilion"
  ],
  "vermilion": [
    "crimson",
    "scarlet",
    "ruby",
    "cherry",
    "vermilion"
  ],
  "blue": [
    "azure",
    "cobalt",
    "navy",
    "sky",
    "cerulean"
  ],
  "azure": [
    "azure",
    "cobalt",
    "navy",
    "sky",
    "cerulean"
  ],
  "cobalt": [
    "azure",
    "cobalt",
    "navy",
    "sky",
    "cerulean"
  ],
  "navy": [
    "azure",
    "cobalt",
    "navy",
    "sky",
    "cerulean"
  ],
  "sky": [
    "azure",
    "cobalt",
    "navy",
    "sky",
    "cerulean"
  ],
  "cerulean": [
    "azure",
    "cobalt",
    "navy",
    "sky",
    "cerulean"
  ],
  "green": [
    "emerald",
    "lime",
    "olive",
    "jade",
    "verdant"
  ],
  "emerald": [
    "emerald",
    "lime",
    "olive",
    "jade",
    "verdant"
  ],
  "lime": [
    "emerald",
    "lime",
    "olive",
    "jade",
    "verdant"
  ],
  "olive": [
    "emerald",
    "lime",
    "olive",
    "jade",
    "verdant"
  ],
  "jade": [
    "emerald",
    "lime",
    "olive",
    "jade",
    "verdant"
  ],
  "verdant": [
    "emerald",
    "lime",
    "olive",
    "jade",
    "verdant"
  ],
  "yellow": [
    "golden",
    "lemon",
    "amber",
    "canary",
    "blonde"
  ],
  "golden": [
    "golden",
    "lemon",
    "amber",
    "canary",
    "blonde"
  ],
  "lemon": [
    "golden",
    "lemon",
    "amber",
    "canary",
    "blonde"
  ],
  "amber": [
    "golden",
    "lemon",
    "amber",
    "canary",
    "blonde"
  ],
  "canary": [
    "golden",
    "lemon",
    "amber",
    "canary",
    "blonde"
  ],
  "blonde": [
    "golden",
    "lemon",
    "amber",
    "canary",
    "blonde"
  ],
  "ebony": [
    "ebony",
    "jet",
    "charcoal",
    "onyx",
    "dark"
  ],
  "jet": [
    "ebony",
    "jet",
    "charcoal",
    "onyx",
    "dark"
  ],
  "charcoal": [
    "ebony",
    "jet",
    "charcoal",
    "onyx",
    "dark"
  ],
  "onyx": [
    "ebony",
    "jet",
    "charcoal",
    "onyx",
    "dark"
  ],
  "white": [
    "ivory",
    "snow",
    "cream",
    "pale",
    "alabaster"
  ],
  "ivory": [
    "ivory",
    "snow",
    "cream",
    "pale",
    "alabaster"
  ],
  "snow": [
    "ivory",
    "snow",
    "cream",
    "pale",
    "alabaster"
  ],
  "cream": [
    "ivory",
    "snow",
    "cream",
    "pale",
    "alabaster"
  ],
  "pale": [
    "ivory",
    "snow",
    "cream",
    "pale",
    "alabaster"
  ],
  "alabaster": [
    "ivory",
    "snow",
    "cream",
    "pale",
    "alabaster"
  ],
  "one": [
    "a",
    "one",
    "some",
    "any"
  ],
  "single": [
    "single",
    "unity",
    "first",
    "solo",
    "ace"
  ],
  "unity": [
    "single",
    "unity",
    "first",
    "solo",
    "ace"
  ],
  "first": [
    "single",
    "unity",
    "first",
    "solo",
    "ace"
  ],
  "solo": [
    "single",
    "unity",
    "first",
    "solo",
    "ace"
  ],
  "ace": [
    "single",
    "unity",
    "first",
    "solo",
    "ace"
  ],
  "two": [
    "pair",
    "duo",
    "couple",
    "twin",
    "double"
  ],
  "pair": [
    "pair",
    "duo",
    "couple",
    "twin",
    "double"
  ],
  "duo": [
    "pair",
    "duo",
    "couple",
    "twin",
    "double"
  ],
  "couple": [
    "pair",
    "duo",
    "couple",
    "twin",
    "double"
  ],
  "twin": [
    "pair",
    "duo",
    "couple",
    "twin",
    "double"
  ],
  "double": [
    "pair",
    "duo",
    "couple",
    "twin",
    "double"
  ],
  "three": [
    "trio",
    "threesome",
    "triad",
    "triplet",
    "triangular"
  ],
  "trio": [
    "trio",
    "threesome",
    "triad",
    "triplet",
    "triangular"
  ],
  "threesome": [
    "trio",
    "threesome",
    "triad",
    "triplet",
    "triangular"
  ],
  "triad": [
    "trio",
    "threesome",
    "triad",
    "triplet",
    "triangular"
  ],
  "triplet": [
    "trio",
    "threesome",
    "triad",
    "triplet",
    "triangular"
  ],
  "triangular": [
    "trio",
    "threesome",
    "triad",
    "triplet",
    "triangular"
  ],
  "monday": [
    "mon",
    "start of week",
    "first day",
    "weekday",
    "workday"
  ],
  "mon": [
    "mon",
    "start of week",
    "first day",
    "weekday",
    "workday"
  ],
  "start of week": [
    "mon",
    "start of week",
    "first day",
    "weekday",
    "workday"
  ],
  "first day": [
    "mon",
    "start of week",
    "first day",
    "weekday",
    "workday"
  ],
  "weekday": [
    "fri",
    "weekday",
    "end of workweek",
    "workday",
    "TGIF"
  ],
  "workday": [
    "fri",
    "weekday",
    "end of workweek",
    "workday",
    "TGIF"
  ],
  "tuesday": [
    "tue",
    "second day",
    "weekday",
    "workday",
    "midweek"
  ],
  "tue": [
    "tue",
    "second day",
    "weekday",
    "workday",
    "midweek"
  ],
  "second day": [
    "tue",
    "second day",
    "weekday",
    "workday",
    "midweek"
  ],
  "midweek": [
    "wed",
    "hump day",
    "midweek",
    "weekday",
    "workday"
  ],
  "wednesday": [
    "wed",
    "hump day",
    "midweek",
    "weekday",
    "workday"
  ],
  "wed": [
    "wed",
    "hump day",
    "midweek",
    "weekday",
    "workday"
  ],
  "hump day": [
    "wed",
    "hump day",
    "midweek",
    "weekday",
    "workday"
  ],
  "thursday": [
    "thu",
    "weekday",
    "almost friday",
    "workday",
    "preweekend"
  ],
  "thu": [
    "thu",
    "weekday",
    "almost friday",
    "workday",
    "preweekend"
  ],
  "almost friday": [
    "thu",
    "weekday",
    "almost friday",
    "workday",
    "preweekend"
  ],
  "preweekend": [
    "thu",
    "weekday",
    "almost friday",
    "workday",
    "preweekend"
  ],
  "friday": [
    "fri",
    "weekday",
    "end of workweek",
    "workday",
    "TGIF"
  ],
  "fri": [
    "fri",
    "weekday",
    "end of workweek",
    "workday",
    "TGIF"
  ],
  "end of workweek": [
    "fri",
    "weekday",
    "end of workweek",
    "workday",
    "TGIF"
  ],
  "TGIF": [
    "fri",
    "weekday",
    "end of workweek",
    "workday",
    "TGIF"
  ],
  "saturday": [
    "sat",
    "weekend",
    "day off",
    "leisure day",
    "holiday"
  ],
  "sat": [
    "sat",
    "weekend",
    "day off",
    "leisure day",
    "holiday"
  ],
  "weekend": [
    "sun",
    "weekend",
    "rest day",
    "holiday",
    "day off"
  ],
  "day off": [
    "sun",
    "weekend",
    "rest day",
    "holiday",
    "day off"
  ],
  "leisure day": [
    "sat",
    "weekend",
    "day off",
    "leisure day",
    "holiday"
  ],
  "holiday": [
    "sun",
    "weekend",
    "rest day",
    "holiday",
    "day off"
  ],
  "sunday": [
    "sun",
    "weekend",
    "rest day",
    "holiday",
    "day off"
  ],
  "sun": [
    "sun",
    "weekend",
    "rest day",
    "holiday",
    "day off"
  ],
  "rest day": [
    "sun",
    "weekend",
    "rest day",
    "holiday",
    "day off"
  ],
  "water": [
    "H2O",
    "aqua",
    "liquid",
    "drink",
    "fluid"
  ],
  "H2O": [
    "H2O",
    "aqua",
    "liquid",
    "drink",
    "fluid"
  ],
  "aqua": [
    "H2O",
    "aqua",
    "liquid",
    "drink",
    "fluid"
  ],
  "liquid": [
    "H2O",
    "aqua",
    "liquid",
    "drink",
    "fluid"
  ],
  "drink": [
    "sip",
    "gulp",
    "imbibe",
    "quaff",
    "swallow"
  ],
  "fluid": [
    "H2O",
    "aqua",
    "liquid",
    "drink",
    "fluid"
  ],
  "food": [
    "meal",
    "nourishment",
    "cuisine",
    "dish",
    "grub"
  ],
  "meal": [
    "meal",
    "nourishment",
    "cuisine",
    "dish",
    "grub"
  ],
  "nourishment": [
    "meal",
    "nourishment",
    "cuisine",
    "dish",
    "grub"
  ],
  "cuisine": [
    "meal",
    "nourishment",
    "cuisine",
    "dish",
    "grub"
  ],
  "dish": [
    "meal",
    "nourishment",
    "cuisine",
    "dish",
    "grub"
  ],
  "grub": [
    "meal",
    "nourishment",
    "cuisine",
    "dish",
    "grub"
  ],
  "car": [
    "vehicle",
    "automobile",
    "ride",
    "wheels",
    "motorcar"
  ],
  "vehicle": [
    "vehicle",
    "automobile",
    "ride",
    "wheels",
    "motorcar"
  ],
  "automobile": [
    "vehicle",
    "automobile",
    "ride",
    "wheels",
    "motorcar"
  ],
  "ride": [
    "vehicle",
    "automobile",
    "ride",
    "wheels",
    "motorcar"
  ],
  "wheels": [
    "vehicle",
    "automobile",
    "ride",
    "wheels",
    "motorcar"
  ],
  "motorcar": [
    "vehicle",
    "automobile",
    "ride",
    "wheels",
    "motorcar"
  ],
  "phone": [
    "cell",
    "mobile",
    "telephone",
    "handset",
    "device"
  ],
  "cell": [
    "cell",
    "mobile",
    "telephone",
    "handset",
    "device"
  ],
  "mobile": [
    "cell",
    "mobile",
    "telephone",
    "handset",
    "device"
  ],
  "telephone": [
    "cell",
    "mobile",
    "telephone",
    "handset",
    "device"
  ],
  "handset": [
    "cell",
    "mobile",
    "telephone",
    "handset",
    "device"
  ],
  "device": [
    "cell",
    "mobile",
    "telephone",
    "handset",
    "device"
  ],
  "mom": [
    "mother",
    "mum",
    "mommy",
    "mama",
    "maternal"
  ],
  "mother": [
    "mother",
    "mum",
    "mommy",
    "mama",
    "maternal"
  ],
  "mum": [
    "mother",
    "mum",
    "mommy",
    "mama",
    "maternal"
  ],
  "mommy": [
    "mother",
    "mum",
    "mommy",
    "mama",
    "maternal"
  ],
  "mama": [
    "mother",
    "mum",
    "mommy",
    "mama",
    "maternal"
  ],
  "maternal": [
    "mother",
    "mum",
    "mommy",
    "mama",
    "maternal"
  ],
  "dad": [
    "father",
    "pop",
    "papa",
    "daddy",
    "paternal"
  ],
  "father": [
    "father",
    "pop",
    "papa",
    "daddy",
    "paternal"
  ],
  "pop": [
    "father",
    "pop",
    "papa",
    "daddy",
    "paternal"
  ],
  "papa": [
    "father",
    "pop",
    "papa",
    "daddy",
    "paternal"
  ],
  "daddy": [
    "father",
    "pop",
    "papa",
    "daddy",
    "paternal"
  ],
  "paternal": [
    "father",
    "pop",
    "papa",
    "daddy",
    "paternal"
  ],
  "brother": [
    "sib",
    "bro",
    "sibling",
    "mate",
    "kin"
  ],
  "sib": [
    "sib",
    "sis",
    "sibling",
    "mate",
    "kin"
  ],
  "bro": [
    "sib",
    "bro",
    "sibling",
    "mate",
    "kin"
  ],
  "sibling": [
    "sib",
    "sis",
    "sibling",
    "mate",
    "kin"
  ],
  "kin": [
    "relatives",
    "household",
    "clan",
    "kin",
    "folk"
  ],
  "sister": [
    "sib",
    "sis",
    "sibling",
    "mate",
    "kin"
  ],
  "sis": [
    "sib",
    "sis",
    "sibling",
    "mate",
    "kin"
  ],
  "family": [
    "relatives",
    "household",
    "clan",
    "kin",
    "folk"
  ],
  "relatives": [
    "relatives",
    "household",
    "clan",
    "kin",
    "folk"
  ],
  "household": [
    "relatives",
    "household",
    "clan",
    "kin",
    "folk"
  ],
  "clan": [
    "relatives",
    "household",
    "clan",
    "kin",
    "folk"
  ],
  "folk": [
    "relatives",
    "household",
    "clan",
    "kin",
    "folk"
  ],
  "angry": [
    "mad",
    "furious",
    "irate",
    "annoyed",
    "upset"
  ],
  "mad": [
    "mad",
    "furious",
    "irate",
    "annoyed",
    "upset"
  ],
  "furious": [
    "mad",
    "furious",
    "irate",
    "annoyed",
    "upset"
  ],
  "irate": [
    "mad",
    "furious",
    "irate",
    "annoyed",
    "upset"
  ],
  "annoyed": [
    "mad",
    "furious",
    "irate",
    "annoyed",
    "upset"
  ],
  "upset": [
    "mad",
    "furious",
    "irate",
    "annoyed",
    "upset"
  ],
  "scared": [
    "afraid",
    "frightened",
    "fearful",
    "terrified",
    "nervous"
  ],
  "afraid": [
    "afraid",
    "frightened",
    "fearful",
    "terrified",
    "nervous"
  ],
  "frightened": [
    "afraid",
    "frightened",
    "fearful",
    "terrified",
    "nervous"
  ],
  "fearful": [
    "afraid",
    "frightened",
    "fearful",
    "terrified",
    "nervous"
  ],
  "terrified": [
    "afraid",
    "frightened",
    "fearful",
    "terrified",
    "nervous"
  ],
  "nervous": [
    "afraid",
    "frightened",
    "fearful",
    "terrified",
    "nervous"
  ],
  "surprised": [
    "shocked",
    "astonished",
    "amazed",
    "stunned",
    "astounded"
  ],
  "shocked": [
    "shocked",
    "astonished",
    "amazed",
    "stunned",
    "astounded"
  ],
  "astonished": [
    "shocked",
    "astonished",
    "amazed",
    "stunned",
    "astounded"
  ],
  "amazed": [
    "shocked",
    "astonished",
    "amazed",
    "stunned",
    "astounded"
  ],
  "stunned": [
    "shocked",
    "astonished",
    "amazed",
    "stunned",
    "astounded"
  ],
  "astounded": [
    "shocked",
    "astonished",
    "amazed",
    "stunned",
    "astounded"
  ],
  "tired": [
    "exhausted",
    "weary",
    "sleepy",
    "fatigued",
    "drained"
  ],
  "exhausted": [
    "exhausted",
    "weary",
    "sleepy",
    "fatigued",
    "drained"
  ],
  "weary": [
    "exhausted",
    "weary",
    "sleepy",
    "fatigued",
    "drained"
  ],
  "sleepy": [
    "exhausted",
    "weary",
    "sleepy",
    "fatigued",
    "drained"
  ],
  "fatigued": [
    "exhausted",
    "weary",
    "sleepy",
    "fatigued",
    "drained"
  ],
  "drained": [
    "exhausted",
    "weary",
    "sleepy",
    "fatigued",
    "drained"
  ],
  "hungry": [
    "starving",
    "famished",
    "peckish",
    "ravenous",
    "empty"
  ],
  "starving": [
    "starving",
    "famished",
    "peckish",
    "ravenous",
    "empty"
  ],
  "famished": [
    "starving",
    "famished",
    "peckish",
    "ravenous",
    "empty"
  ],
  "peckish": [
    "starving",
    "famished",
    "peckish",
    "ravenous",
    "empty"
  ],
  "ravenous": [
    "starving",
    "famished",
    "peckish",
    "ravenous",
    "empty"
  ],
  "empty": [
    "starving",
    "famished",
    "peckish",
    "ravenous",
    "empty"
  ],
  "thirsty": [
    "parched",
    "dehydrated",
    "dry",
    "quenched",
    "sipping"
  ],
  "parched": [
    "parched",
    "dehydrated",
    "dry",
    "quenched",
    "sipping"
  ],
  "dehydrated": [
    "parched",
    "dehydrated",
    "dry",
    "quenched",
    "sipping"
  ],
  "dry": [
    "parched",
    "dehydrated",
    "dry",
    "quenched",
    "sipping"
  ],
  "quenched": [
    "parched",
    "dehydrated",
    "dry",
    "quenched",
    "sipping"
  ],
  "sipping": [
    "parched",
    "dehydrated",
    "dry",
    "quenched",
    "sipping"
  ],
  "eat": [
    "consume",
    "devour",
    "ingest",
    "munch",
    "nibble"
  ],
  "consume": [
    "consume",
    "devour",
    "ingest",
    "munch",
    "nibble"
  ],
  "devour": [
    "consume",
    "devour",
    "ingest",
    "munch",
    "nibble"
  ],
  "ingest": [
    "consume",
    "devour",
    "ingest",
    "munch",
    "nibble"
  ],
  "munch": [
    "consume",
    "devour",
    "ingest",
    "munch",
    "nibble"
  ],
  "nibble": [
    "consume",
    "devour",
    "ingest",
    "munch",
    "nibble"
  ],
  "sip": [
    "sip",
    "gulp",
    "imbibe",
    "quaff",
    "swallow"
  ],
  "gulp": [
    "sip",
    "gulp",
    "imbibe",
    "quaff",
    "swallow"
  ],
  "imbibe": [
    "sip",
    "gulp",
    "imbibe",
    "quaff",
    "swallow"
  ],
  "quaff": [
    "sip",
    "gulp",
    "imbibe",
    "quaff",
    "swallow"
  ],
  "swallow": [
    "sip",
    "gulp",
    "imbibe",
    "quaff",
    "swallow"
  ],
  "sleep": [
    "nap",
    "doze",
    "rest",
    "slumber",
    "snooze"
  ],
  "nap": [
    "nap",
    "doze",
    "rest",
    "slumber",
    "snooze"
  ],
  "doze": [
    "nap",
    "doze",
    "rest",
    "slumber",
    "snooze"
  ],
  "rest": [
    "nap",
    "doze",
    "rest",
    "slumber",
    "snooze"
  ],
  "slumber": [
    "nap",
    "doze",
    "rest",
    "slumber",
    "snooze"
  ],
  "snooze": [
    "nap",
    "doze",
    "rest",
    "slumber",
    "snooze"
  ],
  "run": [
    "sprint",
    "jog",
    "dash",
    "race",
    "hurry"
  ],
  "sprint": [
    "sprint",
    "jog",
    "dash",
    "race",
    "hurry"
  ],
  "jog": [
    "sprint",
    "jog",
    "dash",
    "race",
    "hurry"
  ],
  "dash": [
    "sprint",
    "jog",
    "dash",
    "race",
    "hurry"
  ],
  "race": [
    "sprint",
    "jog",
    "dash",
    "race",
    "hurry"
  ],
  "hurry": [
    "sprint",
    "jog",
    "dash",
    "race",
    "hurry"
  ],
  "stroll": [
    "stroll",
    "saunter",
    "amble",
    "march",
    "wander"
  ],
  "saunter": [
    "stroll",
    "saunter",
    "amble",
    "march",
    "wander"
  ],
  "amble": [
    "stroll",
    "saunter",
    "amble",
    "march",
    "wander"
  ],
  "march": [
    "stroll",
    "saunter",
    "amble",
    "march",
    "wander"
  ],
  "wander": [
    "stroll",
    "saunter",
    "amble",
    "march",
    "wander"
  ],
  "play": [
    "game",
    "frolic",
    "amuse",
    "entertain",
    "recreate"
  ],
  "game": [
    "game",
    "frolic",
    "amuse",
    "entertain",
    "recreate"
  ],
  "frolic": [
    "game",
    "frolic",
    "amuse",
    "entertain",
    "recreate"
  ],
  "amuse": [
    "game",
    "frolic",
    "amuse",
    "entertain",
    "recreate"
  ],
  "entertain": [
    "game",
    "frolic",
    "amuse",
    "entertain",
    "recreate"
  ],
  "recreate": [
    "game",
    "frolic",
    "amuse",
    "entertain",
    "recreate"
  ],
  "work": [
    "labor",
    "job",
    "task",
    "toil",
    "effort"
  ],
  "labor": [
    "labor",
    "job",
    "task",
    "toil",
    "effort"
  ],
  "job": [
    "labor",
    "job",
    "task",
    "toil",
    "effort"
  ],
  "task": [
    "labor",
    "job",
    "task",
    "toil",
    "effort"
  ],
  "toil": [
    "labor",
    "job",
    "task",
    "toil",
    "effort"
  ],
  "effort": [
    "labor",
    "job",
    "task",
    "toil",
    "effort"
  ],
  "school": [
    "academy",
    "institution",
    "college",
    "learning center",
    "edu place"
  ],
  "academy": [
    "academy",
    "institution",
    "college",
    "learning center",
    "edu place"
  ],
  "institution": [
    "academy",
    "institution",
    "college",
    "learning center",
    "edu place"
  ],
  "college": [
    "academy",
    "institution",
    "college",
    "learning center",
    "edu place"
  ],
  "learning center": [
    "academy",
    "institution",
    "college",
    "learning center",
    "edu place"
  ],
  "edu place": [
    "academy",
    "institution",
    "college",
    "learning center",
    "edu place"
  ],
  "office": [
    "workplace",
    "bureau",
    "department",
    "studio",
    "workspace"
  ],
  "workplace": [
    "workplace",
    "bureau",
    "department",
    "studio",
    "workspace"
  ],
  "bureau": [
    "workplace",
    "bureau",
    "department",
    "studio",
    "workspace"
  ],
  "department": [
    "workplace",
    "bureau",
    "department",
    "studio",
    "workspace"
  ],
  "studio": [
    "workplace",
    "bureau",
    "department",
    "studio",
    "workspace"
  ],
  "workspace": [
    "workplace",
    "bureau",
    "department",
    "studio",
    "workspace"
  ],
  "store": [
    "shop",
    "market",
    "boutique",
    "emporium",
    "mart"
  ],
  "shop": [
    "shop",
    "market",
    "boutique",
    "emporium",
    "mart"
  ],
  "market": [
    "shop",
    "market",
    "boutique",
    "emporium",
    "mart"
  ],
  "boutique": [
    "shop",
    "market",
    "boutique",
    "emporium",
    "mart"
  ],
  "emporium": [
    "shop",
    "market",
    "boutique",
    "emporium",
    "mart"
  ],
  "mart": [
    "shop",
    "market",
    "boutique",
    "emporium",
    "mart"
  ],
  "park": [
    "garden",
    "playground",
    "recreation area",
    "green space",
    "commons"
  ],
  "garden": [
    "garden",
    "playground",
    "recreation area",
    "green space",
    "commons"
  ],
  "playground": [
    "garden",
    "playground",
    "recreation area",
    "green space",
    "commons"
  ],
  "recreation area": [
    "garden",
    "playground",
    "recreation area",
    "green space",
    "commons"
  ],
  "green space": [
    "garden",
    "playground",
    "recreation area",
    "green space",
    "commons"
  ],
  "commons": [
    "garden",
    "playground",
    "recreation area",
    "green space",
    "commons"
  ],
  "street": [
    "road",
    "avenue",
    "lane",
    "boulevard",
    "drive"
  ],
  "road": [
    "road",
    "avenue",
    "lane",
    "boulevard",
    "drive"
  ],
  "avenue": [
    "road",
    "avenue",
    "lane",
    "boulevard",
    "drive"
  ],
  "lane": [
    "road",
    "avenue",
    "lane",
    "boulevard",
    "drive"
  ],
  "boulevard": [
    "road",
    "avenue",
    "lane",
    "boulevard",
    "drive"
  ],
  "drive": [
    "road",
    "avenue",
    "lane",
    "boulevard",
    "drive"
  ],
  "room": [
    "chamber",
    "space",
    "area",
    "quarter",
    "compartment"
  ],
  "chamber": [
    "chamber",
    "space",
    "area",
    "quarter",
    "compartment"
  ],
  "space": [
    "chamber",
    "space",
    "area",
    "quarter",
    "compartment"
  ],
  "area": [
    "chamber",
    "space",
    "area",
    "quarter",
    "compartment"
  ],
  "quarter": [
    "chamber",
    "space",
    "area",
    "quarter",
    "compartment"
  ],
  "compartment": [
    "chamber",
    "space",
    "area",
    "quarter",
    "compartment"
  ],
  "bed": [
    "cot",
    "bunk",
    "sleeping place",
    "mattress",
    "resting place"
  ],
  "cot": [
    "cot",
    "bunk",
    "sleeping place",
    "mattress",
    "resting place"
  ],
  "bunk": [
    "cot",
    "bunk",
    "sleeping place",
    "mattress",
    "resting place"
  ],
  "sleeping place": [
    "cot",
    "bunk",
    "sleeping place",
    "mattress",
    "resting place"
  ],
  "mattress": [
    "cot",
    "bunk",
    "sleeping place",
    "mattress",
    "resting place"
  ],
  "resting place": [
    "cot",
    "bunk",
    "sleeping place",
    "mattress",
    "resting place"
  ],
  "chair": [
    "seat",
    "stool",
    "bench",
    "armchair",
    "throne"
  ],
  "seat": [
    "seat",
    "stool",
    "bench",
    "armchair",
    "throne"
  ],
  "stool": [
    "seat",
    "stool",
    "bench",
    "armchair",
    "throne"
  ],
  "bench": [
    "seat",
    "stool",
    "bench",
    "armchair",
    "throne"
  ],
  "armchair": [
    "seat",
    "stool",
    "bench",
    "armchair",
    "throne"
  ],
  "throne": [
    "seat",
    "stool",
    "bench",
    "armchair",
    "throne"
  ],
  "table": [
    "desk",
    "counter",
    "surface",
    "stand",
    "worktop"
  ],
  "desk": [
    "desk",
    "counter",
    "surface",
    "stand",
    "worktop"
  ],
  "counter": [
    "desk",
    "counter",
    "surface",
    "stand",
    "worktop"
  ],
  "surface": [
    "desk",
    "counter",
    "surface",
    "stand",
    "worktop"
  ],
  "stand": [
    "exist",
    "remain",
    "stand",
    "constitute",
    "represent"
  ],
  "worktop": [
    "desk",
    "counter",
    "surface",
    "stand",
    "worktop"
  ],
  "the": [
    "this",
    "that",
    "these",
    "those"
  ],
  "this": [
    "this",
    "that",
    "these",
    "those"
  ],
  "that": [
    "this",
    "that",
    "these",
    "those"
  ],
  "these": [
    "this",
    "that",
    "these",
    "those"
  ],
  "those": [
    "this",
    "that",
    "these",
    "those"
  ],
  "a": [
    "a",
    "one",
    "some",
    "any"
  ],
  "an": [
    "a",
    "one",
    "some",
    "any"
  ],
  "some": [
    "a",
    "one",
    "some",
    "any"
  ],
  "any": [
    "a",
    "one",
    "some",
    "any"
  ],
  "and": [
    "plus",
    "also",
    "with",
    "in addition",
    "as well"
  ],
  "plus": [
    "accompanied by",
    "alongside",
    "together with",
    "including",
    "plus"
  ],
  "also": [
    "plus",
    "also",
    "with",
    "in addition",
    "as well"
  ],
  "with": [
    "accompanied by",
    "alongside",
    "together with",
    "including",
    "plus"
  ],
  "in addition": [
    "plus",
    "also",
    "with",
    "in addition",
    "as well"
  ],
  "as well": [
    "plus",
    "also",
    "with",
    "in addition",
    "as well"
  ],
  "or": [
    "either",
    "alternatively",
    "else",
    "otherwise",
    "nor"
  ],
  "either": [
    "either",
    "alternatively",
    "else",
    "otherwise",
    "nor"
  ],
  "alternatively": [
    "either",
    "alternatively",
    "else",
    "otherwise",
    "nor"
  ],
  "else": [
    "either",
    "alternatively",
    "else",
    "otherwise",
    "nor"
  ],
  "otherwise": [
    "either",
    "alternatively",
    "else",
    "otherwise",
    "nor"
  ],
  "nor": [
    "either",
    "alternatively",
    "else",
    "otherwise",
    "nor"
  ],
  "but": [
    "however",
    "yet",
    "still",
    "though",
    "nevertheless"
  ],
  "however": [
    "however",
    "yet",
    "still",
    "though",
    "nevertheless"
  ],
  "yet": [
    "however",
    "yet",
    "still",
    "though",
    "nevertheless"
  ],
  "still": [
    "however",
    "yet",
    "still",
    "though",
    "nevertheless"
  ],
  "though": [
    "however",
    "yet",
    "still",
    "though",
    "nevertheless"
  ],
  "nevertheless": [
    "however",
    "yet",
    "still",
    "though",
    "nevertheless"
  ],
  "if": [
    "provided",
    "assuming",
    "in case",
    "on condition",
    "supposing"
  ],
  "provided": [
    "provided",
    "assuming",
    "in case",
    "on condition",
    "supposing"
  ],
  "assuming": [
    "provided",
    "assuming",
    "in case",
    "on condition",
    "supposing"
  ],
  "in case": [
    "provided",
    "assuming",
    "in case",
    "on condition",
    "supposing"
  ],
  "on condition": [
    "provided",
    "assuming",
    "in case",
    "on condition",
    "supposing"
  ],
  "supposing": [
    "provided",
    "assuming",
    "in case",
    "on condition",
    "supposing"
  ],
  "in": [
    "by",
    "near",
    "around",
    "toward",
    "in"
  ],
  "inside": [
    "inside",
    "within",
    "into",
    "through",
    "during"
  ],
  "within": [
    "inside",
    "within",
    "into",
    "through",
    "during"
  ],
  "into": [
    "toward",
    "into",
    "until",
    "for",
    "onto"
  ],
  "through": [
    "inside",
    "within",
    "into",
    "through",
    "during"
  ],
  "during": [
    "inside",
    "within",
    "into",
    "through",
    "during"
  ],
  "on": [
    "upon",
    "above",
    "over",
    "atop",
    "regarding"
  ],
  "upon": [
    "upon",
    "above",
    "over",
    "atop",
    "regarding"
  ],
  "over": [
    "upon",
    "above",
    "over",
    "atop",
    "regarding"
  ],
  "atop": [
    "upon",
    "above",
    "over",
    "atop",
    "regarding"
  ],
  "regarding": [
    "belonging to",
    "from",
    "about",
    "concerning",
    "regarding"
  ],
  "at": [
    "by",
    "near",
    "around",
    "toward",
    "in"
  ],
  "by": [
    "by",
    "near",
    "around",
    "toward",
    "in"
  ],
  "near": [
    "by",
    "near",
    "around",
    "toward",
    "in"
  ],
  "around": [
    "by",
    "near",
    "around",
    "toward",
    "in"
  ],
  "toward": [
    "intended for",
    "meant for",
    "on behalf of",
    "in favor of",
    "toward"
  ],
  "to": [
    "toward",
    "into",
    "until",
    "for",
    "onto"
  ],
  "until": [
    "toward",
    "into",
    "until",
    "for",
    "onto"
  ],
  "for": [
    "intended for",
    "meant for",
    "on behalf of",
    "in favor of",
    "toward"
  ],
  "onto": [
    "toward",
    "into",
    "until",
    "for",
    "onto"
  ],
  "intended for": [
    "intended for",
    "meant for",
    "on behalf of",
    "in favor of",
    "toward"
  ],
  "meant for": [
    "intended for",
    "meant for",
    "on behalf of",
    "in favor of",
    "toward"
  ],
  "on behalf of": [
    "intended for",
    "meant for",
    "on behalf of",
    "in favor of",
    "toward"
  ],
  "in favor of": [
    "intended for",
    "meant for",
    "on behalf of",
    "in favor of",
    "toward"
  ],
  "accompanied by": [
    "accompanied by",
    "alongside",
    "together with",
    "including",
    "plus"
  ],
  "alongside": [
    "accompanied by",
    "alongside",
    "together with",
    "including",
    "plus"
  ],
  "together with": [
    "accompanied by",
    "alongside",
    "together with",
    "including",
    "plus"
  ],
  "including": [
    "accompanied by",
    "alongside",
    "together with",
    "including",
    "plus"
  ],
  "of": [
    "belonging to",
    "from",
    "about",
    "concerning",
    "regarding"
  ],
  "belonging to": [
    "belonging to",
    "from",
    "about",
    "concerning",
    "regarding"
  ],
  "from": [
    "belonging to",
    "from",
    "about",
    "concerning",
    "regarding"
  ],
  "about": [
    "belonging to",
    "from",
    "about",
    "concerning",
    "regarding"
  ],
  "concerning": [
    "belonging to",
    "from",
    "about",
    "concerning",
    "regarding"
  ],
  "is": [
    "equals",
    "represents",
    "remains",
    "exists",
    "stands as"
  ],
  "equals": [
    "equals",
    "represents",
    "remains",
    "exists",
    "stands as"
  ],
  "represents": [
    "equals",
    "represents",
    "remains",
    "exists",
    "stands as"
  ],
  "remains": [
    "equals",
    "represents",
    "remains",
    "exists",
    "stands as"
  ],
  "exists": [
    "equals",
    "represents",
    "remains",
    "exists",
    "stands as"
  ],
  "stands as": [
    "equals",
    "represents",
    "remains",
    "exists",
    "stands as"
  ],
  "are": [
    "exist",
    "remain",
    "stand",
    "constitute",
    "represent"
  ],
  "exist": [
    "exist",
    "remain",
    "stand",
    "constitute",
    "represent"
  ],
  "remain": [
    "exist",
    "remain",
    "stand",
    "constitute",
    "represent"
  ],
  "constitute": [
    "exist",
    "remain",
    "stand",
    "constitute",
    "represent"
  ],
  "represent": [
    "exist",
    "remain",
    "stand",
    "constitute",
    "represent"
  ],
  "was": [
    "existed",
    "remained",
    "stood",
    "occurred",
    "happened"
  ],
  "existed": [
    "existed",
    "remained",
    "stood",
    "occurred",
    "happened"
  ],
  "remained": [
    "existed",
    "remained",
    "stood",
    "occurred",
    "happened"
  ],
  "stood": [
    "existed",
    "remained",
    "stood",
    "occurred",
    "happened"
  ],
  "occurred": [
    "existed",
    "remained",
    "stood",
    "occurred",
    "happened"
  ],
  "happened": [
    "existed",
    "remained",
    "stood",
    "occurred",
    "happened"
  ],
  "were": [
    "existed",
    "remained",
    "stood",
    "occurred",
    "happened"
  ],
  "has": [
    "possesses",
    "owns",
    "contains",
    "holds",
    "includes"
  ],
  "possesses": [
    "possesses",
    "owns",
    "contains",
    "holds",
    "includes"
  ],
  "owns": [
    "possesses",
    "owns",
    "contains",
    "holds",
    "includes"
  ],
  "contains": [
    "possesses",
    "owns",
    "contains",
    "holds",
    "includes"
  ],
  "holds": [
    "possesses",
    "owns",
    "contains",
    "holds",
    "includes"
  ],
  "includes": [
    "possesses",
    "owns",
    "contains",
    "holds",
    "includes"
  ],
  "have": [
    "possess",
    "own",
    "contain",
    "hold",
    "include"
  ],
  "possess": [
    "possess",
    "own",
    "contain",
    "hold",
    "include"
  ],
  "own": [
    "possess",
    "own",
    "contain",
    "hold",
    "include"
  ],
  "contain": [
    "possess",
    "own",
    "contain",
    "hold",
    "include"
  ],
  "include": [
    "possess",
    "own",
    "contain",
    "hold",
    "include"
  ],
  "does": [
    "performs",
    "carries out",
    "executes",
    "acts",
    "accomplishes"
  ],
  "performs": [
    "performs",
    "carries out",
    "executes",
    "acts",
    "accomplishes"
  ],
  "carries out": [
    "performs",
    "carries out",
    "executes",
    "acts",
    "accomplishes"
  ],
  "executes": [
    "performs",
    "carries out",
    "executes",
    "acts",
    "accomplishes"
  ],
  "acts": [
    "performs",
    "carries out",
    "executes",
    "acts",
    "accomplishes"
  ],
  "accomplishes": [
    "performs",
    "carries out",
    "executes",
    "acts",
    "accomplishes"
  ]
}

